
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>&#1055;&#1088;&#1080;&#1086;&#1073;&#1088;&#1077;&#1089;&#1090;&#1080; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1076;&#1086;&#1084;&#1086;&#1074; &#1055;&#1088;&#1080;&#1086;&#1073;&#1088;&#1077;&#1089;&#1090;&#1080; &#1085;&#1077;&#1076;&#1086;&#1088;&#1086;&#1075;&#1080;&#1077; &#1076;&#1086;&#1084;&#1072; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1044;&#1086;&#1084;&#1072; &#1076;&#1083;&#1103; &#1086;&#1090;&#1076;&#1099;&#1093;&#1072; &#1040;&#1088;&#1077;&#1085;&#1076;&#1072; &#1085;&#1072; &#1082;&#1086;&#1088;&#1086;&#1090;&#1082;&#1080;&#1080;&#774; &#1089;&#1088;&#1086;&#1082;</title>
<meta name="keywords" content="&#1042;&#1080;&#1083;&#1083;&#1099; &mdash; &#1044;&#1086;&#1084;&#1072;, &#1096;&#1072;&#1083;&#1077;, &#1092;&#1077;&#1088;&#1084;&#1099;, &#1087;&#1083;&#1072;&#1074;&#1091;&#1095;&#1080;&#1077; &#1076;&#1086;&#1084;&#1072;, &#1090;&#1072;&#1091;&#1085;-&#1093;&#1072;&#1091;&#1089;&#1099;, &#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1085;&#1099;&#1077; &#1076;&#1086;&#1084;&#1072;, &#1079;&#1072;&#1075;&#1086;&#1088;&#1086;&#1076;&#1085;&#1099;&#1077; &#1076;&#1086;&#1084;&#1072;, &#1079;&#1077;&#1084;&#1077;&#1083;&#1100;&#1085;&#1099;&#1077; &#1091;&#1095;&#1072;&#1089;&#1090;&#1082;&#1080;, &#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1099;, &#1082;&#1086;&#1090;&#1090;&#1077;&#1076;&#1078;&#1080;, &#1076;&#1077;&#1088;&#1077;&#1074;&#1103;&#1085;&#1085;&#1099;&#1077; &#1076;&#1086;&#1084;&#1072;, &#1087;&#1083;&#1072;&#1085;&#1090;&#1072;&#1094;&#1080;&#1080;, &#1074;&#1090;&#1086;&#1088;&#1080;&#1095;&#1085;&#1086;&#1077; &#1078;&#1080;&#1083;&#1100;&#1077;, &#1087;&#1086;&#1080;&#1089;&#1082; &#1086;&#1073;&#1098;&#1077;&#1082;&#1090;&#1086;&#1074; &#1085;&#1077;&#1079;&#1072;&#1074;&#1077;&#1088;&#1096;&#1077;&#1085;&#1085;&#1086;&#1075;&#1086; &#1089;&#1090;&#1088;&#1086;&#1080;&#1090;&#1077;&#1083;&#1100;&#1089;&#1090;&#1074;&#1072;, &#1085;&#1086;&#1074;&#1086;&#1089;&#1090;&#1088;&#1086;&#1080;&#774;&#1082;&#1080;, &#1073;&#1072;&#1088;&#1099;-&#1088;&#1077;&#1089;&#1090;&#1086;&#1088;&#1072;&#1085;&#1099;, &#1075;&#1086;&#1089;&#1090;&#1080;&#1085;&#1080;&#1094;&#1099;, &#1082;&#1086;&#1084;&#1084;&#1077;&#1088;&#1095;&#1077;&#1089;&#1082;&#1072;&#1103; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;">
<meta name="description" content="holprop.ru &#1055;&#1088;&#1080;&#1086;&#1073;&#1088;&#1077;&#1089;&#1090;&#1080; &#1085;&#1077;&#1076;&#1086;&#1088;&#1086;&#1075;&#1080;&#1077; &#1076;&#1086;&#1084;&#1072; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080; &#1085;&#1077;&#1079;&#1072;&#1074;&#1077;&#1088;&#1096;&#1077;&#1085;&#1085;&#1086;&#1077; &#1089;&#1090;&#1088;&#1086;&#1080;&#1090;&#1077;&#1083;&#1100;&#1089;&#1090;&#1074;&#1086; &#1040;&#1088;&#1077;&#1085;&#1076;&#1072; &#1085;&#1072; &#1074;&#1099;&#1093;&#1086;&#1076;&#1085;&#1099;&#1077;, &#1076;&#1086;&#1084;&#1072; &#1076;&#1083;&#1103; &#1086;&#1090;&#1076;&#1099;&#1093;&#1072; &#1087;&#1088;&#1077;&#1076;&#1083;&#1086;&#1078;&#1077;&#1085;&#1080;&#1103; &#1087;&#1086; &#1072;&#1088;&#1077;&#1085;&#1076;&#1077; &#1089;&#1086; &#1074;&#1089;&#1077;&#1075;&#1086; &#1084;&#1080;&#1088;&#1072;!">
<meta name="Updated" content="daily">
<meta name="Distribution" content="Global">
<meta name="robots" content="index,follow">
<meta name="content-language" content="RU">
<meta name="google-site-verification" content="gnqtGNc8knAktZfDBegLVYobKmTKiOehXGqt6Ruk_f4">
<meta property="og:title" content="Check out these amazing real estate listings.">
<meta property="og:type" content="website">
<meta property="og:url" content="http://www.holprop.com">
<meta property="og:image" content="http://www.holprop.com/images/fb.jpg">
<meta property="og:site_name" content="Holprop">
<meta property="fb:admins" content="642906054,100002374527327">
<meta property="og:description" content="www.holprop.com showcasing world`s best properties, 100,000 international real estate listings, sales and rentals.">


<link href="CSS-2013.css" rel="stylesheet" type="text/css">

<script type="text/javascript">         
        function Repl_img(sender)
        {
            sender.src = "http://www.holprop.ru/images/sold_property.jpg";
        }
    </script>
<script SRC="jscripts/ajax_home.js" type="text/JavaScript"></script>
<script type="text/JavaScript">
<!--
function CheckForm()
{
	var theform = document.searchsalefrm;
	var bMissingFields = false;
	var strFields = "";
	
	if( theform.scr.value == '' && (theform.txtCityOrTown.value == '' || theform.txtCityOrTown.value == 'Quick search - Enter Town')){
		
		alert( "You must select at least 'Country' or type a 'Town' to start your search");
		return false;
	}
	return true;
}


function consaleselected()
	{
		Initialize("Any", "srg", "searchsalefrm");


		if(document.searchsalefrm.scr.value != "")
		{
			url = "get_region-county-city-home.asp";
			
				what = "SetSubcat(req.responseText, 'citytxt', 'citydrp', 'searchsalefrm')";


			DoCallback("propType=S&Country="+escape(document.searchsalefrm.scr.value));
		}
		else{
			url = "get_region-county-city-home.asp";
			
				what = "SetSubcat(req.responseText, 'citytxt', 'citydrp', 'searchsalefrm')";

			DoCallback("propType=S&Country="+escape(document.searchsalefrm.scr.value));
		}
	}
	function regselectedsale()
	{
		//Initialize("Any", "sct");
		Initialize("Any", "sltcity", "searchsalefrm");

		if(document.searchsalefrm.srg.value != "")
		{
			url = "get_region-county-city-home.asp";
			
				what = "SetSubcat(req.responseText, 'citytxt', 'citydrp', 'searchsalefrm')";

			DoCallback("propType=S&Country="+escape(document.searchsalefrm.scr.value)+"&Region="+escape(document.searchsalefrm.srg.value));
		}
		else{
			url = "get_region-county-city-home.asp";
			
				what = "SetSubcat(req.responseText, 'citytxt', 'citydrp', 'searchsalefrm')";

			DoCallback("propType=S&Country="+escape(document.searchsalefrm.scr.value)+"&Region="+escape(document.searchsalefrm.srg.value));
		}
	}

	function countyselectedsale()
	{
		//Initialize("Any", "sltcity");

		if(document.searchsalefrm.sct.value != "")
		{
			url = "get_region-county-city-home.asp";
			what = "SetSubcat(req.responseText, 'sltcity')";
			DoCallback("propType=S&Country="+escape(document.searchsalefrm.scr.value)+"&Region="+escape(document.searchsalefrm.srg.value)+"&County="+escape(document.searchsalefrm.sct.value));
		}
	}

//-->
</script>
<script type="text/javascript">
function show_loading(){
var loadingAnim = document.getElementById('pub_loading');
loadingAnim.innerHTML = '<div id="floatingBarsG"><div class="blockG" id="rotateG_01"></div><div class="blockG" id="rotateG_02"></div><div class="blockG" id="rotateG_03"></div><div class="blockG" id="rotateG_04"></div><div class="blockG" id="rotateG_05"></div><div class="blockG" id="rotateG_06"></div><div class="blockG" id="rotateG_07"></div><div class="blockG" id="rotateG_08"></div></div>';
loadingAnim.style.display = 'inline';
}
function show_loading22(){
var loadingAnim = document.getElementById('pub_loading22');
loadingAnim.innerHTML = '<div id="floatingBarsG"><div class="blockG" id="rotateG_01"></div><div class="blockG" id="rotateG_02"></div><div class="blockG" id="rotateG_03"></div><div class="blockG" id="rotateG_04"></div><div class="blockG" id="rotateG_05"></div><div class="blockG" id="rotateG_06"></div><div class="blockG" id="rotateG_07"></div><div class="blockG" id="rotateG_08"></div></div>';
loadingAnim.style.display = 'inline';
}
function show_loading33(){
var loadingAnim = document.getElementById('pub_loading33');
loadingAnim.innerHTML = '<div id="floatingBarsG"><div class="blockG" id="rotateG_01"></div><div class="blockG" id="rotateG_02"></div><div class="blockG" id="rotateG_03"></div><div class="blockG" id="rotateG_04"></div><div class="blockG" id="rotateG_05"></div><div class="blockG" id="rotateG_06"></div><div class="blockG" id="rotateG_07"></div><div class="blockG" id="rotateG_08"></div></div>';
loadingAnim.style.display = 'inline';
}
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
</script>
<style type="text/css">
<!--
body {
	overflow-x: hidden;
}
#pub_loading22 {
                        display:none;
						font-family: Verdana;
						font-size: 8pt;
						color:#0066CC;
}
#pub_loading33 {
                        display:none;
						font-family: Verdana;
						font-size: 8pt;
						color:#0066CC;
}
-->
</style>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js" type="text/JavaScript"></script>
	<script type="text/javascript">
		$(function() {
		
			$("#slideshow > div:gt(0)").hide();
	
			setInterval(function() { 
			  $('#slideshow > div:first')
			    .fadeOut(1000)
			    .next()
			    .fadeIn(1000)
			    .end()
			    .appendTo('#slideshow');
			},  7000);
			
		});
	</script>


</head>
<body>
<div id="wrapper">
<div id="headerH1">
<H1>&#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080; &#1080; &#1072;&#1088;&#1077;&#1085;&#1076;&#1072; &#1076;&#1086;&#1084;&#1086;&#1074; &#1076;&#1083;&#1103; &#1086;&#1090;&#1076;&#1099;&#1093;&#1072; &#1079;&#1072; &#1075;&#1088;&#1072;&#1085;&#1080;&#1094;&#1077;&#1080;&#774;!</H1>
</div>

<div id="head">
<div id="header" align="right">
  <div style="padding-top:2px; width:140px; position:relative; z-index:1"><img src="http://www.holprop.ru/images/languagesfront.jpg" alt="Languages" width="124" height="20" border="0" usemap="#Map">&nbsp;
              <map name="Map" id="Map">
               <area shape="rect" coords="105,3,121,18" href="http://www.holprop.ru" alt="&#1056;&#1091;&#1089;&#1089;&#1082;&#1080;&#1081;">
                <area shape="rect" coords="88,3,104,18" href="http://www.holprop.it" alt="&#1048;&#1090;&#1072;&#1083;&#1100;&#1103;&#1085;&#1089;&#1082;&#1080;&#1081;">
                <area shape="rect" coords="71,3,87,18" href="http://www.holprop.es" alt="&#1048;&#1089;&#1087;&#1072;&#1085;&#1089;&#1082;&#1080;&#1081;">
                <area shape="rect" coords="54,3,70,18" href="http://www.holprop.nl" alt="&#1053;&#1080;&#1076;&#1077;&#1088;&#1083;&#1072;&#1085;&#1076;&#1089;&#1082;&#1080;&#1081;">
                <area shape="rect" coords="37,3,53,18" href="http://www.holprop.fr" alt="&#1060;&#1088;&#1072;&#1085;&#1094;&#1091;&#1079;&#1089;&#1082;&#1080;&#1081;">
                <area shape="rect" coords="2,2,18,18" href="http://www.holprop.com" alt="&#1040;&#1085;&#1075;&#1083;&#1080;&#1081;&#1089;&#1082;&#1080;&#1081;">
                <area shape="rect" coords="20,3,36,18" href="http://www.holprop.de" alt="&#1053;&#1077;&#1084;&#1077;&#1094;&#1082;&#1080;&#1081;">
    </map></div>
	
		<ul>
<li><a href="https://www.holprop.com/login.asp" title="&#1051;&#1086;&#1075;&#1080;&#1085;">&#1051;&#1086;&#1075;&#1080;&#1085;<br>&#1088;&#1072;&#1081;&#1086;&#1085;&#1072;</a></li>
<li><a href="http://www.holprop.com/agents/" title="&#1044;&#1072;&#1090;&#1100; &#1086;&#1073;&#1098;&#1103;&#1074;&#1083;&#1077;&#1085;&#1080;&#1077;">&#1044;&#1072;&#1090;&#1100;<br>&#1086;&#1073;&#1098;&#1103;&#1074;&#1083;&#1077;&#1085;&#1080;&#1077;</a></li>
<li><a href="http://www.longtermlettings.com/" title="&#1076;&#1086;&#1083;&#1075;&#1086;&#1089;&#1088;&#1086;&#1095;&#1085;&#1072;&#1103; &#1072;&#1088;&#1077;&#1085;&#1076;&#1072;">&#1076;&#1086;&#1083;&#1075;&#1086;&#1089;&#1088;&#1086;&#1095;&#1085;&#1072;&#1103;<br>&#1072;&#1088;&#1077;&#1085;&#1076;&#1072;</a></li>
<li><a href="http://www.holprop.ru/holiday_rentals.htm" title="&#1040;&#1088;&#1077;&#1085;&#1076;&#1072; &#1074;&#1099;&#1093;&#1086;&#1076;&#1085;&#1099;&#1077;">&#1040;&#1088;&#1077;&#1085;&#1076;&#1072;<br>&#1074;&#1099;&#1093;&#1086;&#1076;&#1085;&#1099;&#1077;</a></li>
<li><a href="http://www.holprop.ru/property_sales.htm" title="&#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;">&#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072;<br>&#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;</a></li>
	  </ul>


  </div></div>
  
<div class="index-table">
<div class="floatleft" style="padding-left:5px">
<div id="searchbox" class="search-item">
<div id="homelink">
            <a href="http://www.holprop.ru/" title="www.holprop.ru | &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;"><img src="http://www.holprop.ru/images/homespace.gif" alt="www.holprop.ru | &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;" width="215" height="82" border="0"></a></div>
<form name="searchsalefrm" action="http://www.holprop.ru/property_sales_ru.asp?sort=asc" method="get" onSubmit="return show_loading();">
                  <input type="hidden" name="searchmode" value="SubmitSearch">
                  <input type="hidden" name="s" value="s">
<div align="center" class="search-white" style="padding-top:6px">
     75 675 &#1086;&#1073;&#1098;&#1077;&#1082;&#1090;&#1086;&#1074; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;
</div>
<div class="label">
&#1057;&#1090;&#1088;&#1072;&#1085;&#1072;:
</div>
<div class="searchitem">
<select name="scr" class="textsmall" onChange="consaleselected()" style="width:154px">
                                <option value="">&#1051;&#1102;&#1073;&#1086;&#1080;</option>
                                
                                <option value="Cont6" class="textsmallred">&raquo; &#1045;&#1074;&#1088;&#1086;&#1087;&#1072;</option>
                                
                                <option value="Albania">&nbsp;&#1040;&#1083;&#1073;&#1072;&#1085;&#1080;&#1103; (247)</option>
                                
                                <option value="Austria">&nbsp;&#1040;&#1074;&#1089;&#1090;&#1088;&#1080;&#1103; (3)</option>
                                
                                <option value="Bulgaria">&nbsp;&#1041;&#1086;&#1083;&#1075;&#1072;&#1088;&#1080;&#1103; (5943)</option>
                                
                                <option value="Croatia">&nbsp;&#1061;&#1086;&#1088;&#1074;&#1072;&#1090;&#1080;&#1103; (567)</option>
                                
                                <option value="Cyprus">&nbsp;&#1050;&#1080;&#1087;&#1088; (2436)</option>
                                
                                <option value="Czech Republic">&nbsp;&#1063;&#1077;&#1093;&#1080;&#1103; (1)</option>
                                
                                <option value="England">&nbsp;&#1040;&#1085;&#1075;&#1083;&#1080;&#1103; (10)</option>
                                
                                <option value="Estonia">&nbsp;&#1069;&#1089;&#1090;&#1086;&#1085;&#1080;&#1103; (1)</option>
                                
                                <option value="France">&nbsp;&#1060;&#1088;&#1072;&#1085;&#1094;&#1080;&#1103; (4115)</option>
                                
                                <option value="Germany">&nbsp;&#1043;&#1077;&#1088;&#1084;&#1072;&#1085;&#1080;&#1103; (19)</option>
                                
                                <option value="Gibraltar">&nbsp;&#1043;&#1080;&#1073;&#1088;&#1072;&#1083;&#1090;&#1072;&#1088; (1)</option>
                                
                                <option value="Greece">&nbsp;&#1043;&#1088;&#1077;&#1094;&#1080;&#1103; (1744)</option>
                                
                                <option value="Hungary">&nbsp;&#1042;&#1077;&#1085;&#1075;&#1088;&#1080;&#1103; (443)</option>
                                
                                <option value="Ireland-South">&nbsp;&#1048;&#1088;&#1083;&#1072;&#1085;&#1076;&#1080;&#1103;-&#1070;&#1075; (1)</option>
                                
                                <option value="Italy">&nbsp;&#1048;&#1090;&#1072;&#1083;&#1080;&#1103; (3277)</option>
                                
                                <option value="Macedonia">&nbsp;&#1052;&#1072;&#1082;&#1077;&#1076;&#1086;&#1085;&#1080;&#1103; (1)</option>
                                
                                <option value="Malta">&nbsp;&#1052;&#1072;&#1083;&#1100;&#1090;&#1072; (632)</option>
                                
                                <option value="Monaco">&nbsp;&#1052;&#1086;&#1085;&#1072;&#1082;&#1086; (2)</option>
                                
                                <option value="Montenegro">&nbsp;&#1063;&#1077;&#1088;&#1085;&#1086;&#1075;&#1086;&#1088;&#1080;&#1103; (1)</option>
                                
                                <option value="Norway">&nbsp;&#1053;&#1086;&#1088;&#1074;&#1077;&#1075;&#1080;&#1103; (1)</option>
                                
                                <option value="Poland">&nbsp;&#1055;&#1086;&#1083;&#1100;&#1096;&#1072; (1)</option>
                                
                                <option value="Portugal">&nbsp;&#1055;&#1086;&#1088;&#1090;&#1091;&#1075;&#1072;&#1083;&#1080;&#1103; (6407)</option>
                                
                                <option value="Russia">&nbsp;&#1056;&#1086;&#1089;&#1089;&#1080;&#1103; (1)</option>
                                
                                <option value="Serbia">&nbsp;&#1057;&#1077;&#1088;&#1073;&#1080;&#1103; (2)</option>
                                
                                <option value="Slovakia">&nbsp;&#1057;&#1083;&#1086;&#1074;&#1072;&#1082;&#1080;&#1103; (1)</option>
                                
                                <option value="Slovenia">&nbsp;&#1057;&#1083;&#1086;&#1074;&#1077;&#1085;&#1080;&#1103; (1)</option>
                                
                                <option value="Spain">&nbsp;&#1048;&#1089;&#1087;&#1072;&#1085;&#1080;&#1103; (16945)</option>
                                
                                <option value="Sweden">&nbsp;&#1064;&#1074;&#1077;&#1094;&#1080;&#1103; (1)</option>
                                
                                <option value="Switzerland">&nbsp;&#1064;&#1074;&#1077;&#1081;&#1094;&#1072;&#1088;&#1080;&#1103; (68)</option>
                                
                                <option value="Turkey">&nbsp;&#1058;&#1091;&#1088;&#1094;&#1080;&#1103; (2043)</option>
                                
                                <option value="Wales">&nbsp;&#1059;&#1101;&#1083;&#1100;&#1089; (2)</option>
                                
                                <option value="Cont8" class="textsmallred">&raquo; &#1057;&#1077;&#1074;&#1077;&#1088;&#1085;&#1072;&#1103; &#1040;&#1084;&#1077;&#1088;&#1080;&#1082;&#1072;</option>
                                
                                <option value="Canada">&nbsp;&#1050;&#1072;&#1085;&#1072;&#1076;&#1072; (1)</option>
                                
                                <option value="Mexico">&nbsp;&#1052;&#1077;&#1082;&#1089;&#1080;&#1082;&#1072; (10)</option>
                                
                                <option value="USA">&nbsp;&#1040;&#1084;&#1077;&#1088;&#1080;&#1082;&#1072; (5050)</option>
                                
                                <option value="Cont5" class="textsmallred">&raquo; &#1050;&#1072;&#1088;&#1080;&#1073;&#1089;&#1082;&#1080;&#1081;</option>
                                
                                <option value="Bahamas">&nbsp;&#1041;&#1072;&#1075;&#1072;&#1084;&#1089;&#1082;&#1080;&#1077; &#1054;&#1089;&#1090;&#1088;&#1086;&#1074;&#1072; (4)</option>
                                
                                <option value="Barbados">&nbsp;&#1041;&#1072;&#1088;&#1073;&#1072;&#1076;&#1086;&#1089; (193)</option>
                                
                                <option value="Cayman Island">&nbsp;&#1050;&#1072;&#1081;&#1084;&#1072;&#1085;&#1086;&#1074;&#1099; &#1086;&#1089;&#1090;&#1088;&#1086;&#1074;&#1072; (3)</option>
                                
                                <option value="Dominican Republic">&nbsp;&#1044;&#1086;&#1084;&#1080;&#1085;&#1080;&#1082;&#1072;&#1085;&#1089;&#1082;&#1072;&#1103; &#1056;&#1077;&#1089;&#1087;&#1091;&#1073;&#1083;&#1080;&#1082;&#1072; (17)</option>
                                
                                <option value="Grenada-Carriacou">&nbsp;&#1043;&#1088;&#1077;&#1085;&#1072;&#1076;&#1072;-Cardiacudu (1)</option>
                                
                                <option value="Jamaica">&nbsp;&#1071;&#1084;&#1072;&#1081;&#1082;&#1072; (2)</option>
                                
                                <option value="St. Kitts-Nevis">&nbsp;&#1057;&#1077;&#1085;&#1090;-&#1050;&#1080;&#1090;&#1089;-&#1053;&#1077;&#1074;&#1080;&#1089; (12)</option>
                                
                                <option value="St. Lucia">&nbsp;&#1057;&#1077;&#1085;&#1090;-&#1051;&#1102;&#1089;&#1080;&#1103; (84)</option>
                                
                                <option value="St. Maarten">&nbsp;&#1057;&#1077;&#1085;-&#1052;&#1072;&#1088;&#1090;&#1077;&#1085; (6)</option>
                                
                                <option value="St. Vincent-Grenadines">&nbsp;&#1057;&#1077;&#1085;&#1090;-&#1042;&#1080;&#1085;&#1089;&#1077;&#1085;&#1090;-Granadines (26)</option>
                                
                                <option value="Cont3" class="textsmallred">&raquo; &#1040;&#1074;&#1089;&#1090;&#1088;&#1072;&#1083;&#1080;&#1103;T&#1080;&#1093;&#1080;&#1081; &#1086;&#1082;&#1077;&#1072;&#1085;</option>
                                
                                <option value="Australia">&nbsp;&#1040;&#1074;&#1089;&#1090;&#1088;&#1072;&#1083;&#1080;&#1103; (2)</option>
                                
                                <option value="Fiji">&nbsp;&#1060;&#1080;&#1076;&#1078;&#1080; (1)</option>
                                
                                <option value="New Zealand">&nbsp;&#1053;&#1086;&#1074;&#1072;&#1103; &#1047;&#1077;&#1083;&#1072;&#1085;&#1076;&#1080;&#1103; (2)</option>
                                
                                <option value="Vanuatu">&nbsp;&#1042;&#1072;&#1085;&#1091;&#1072;&#1090;&#1091; (1)</option>
                                
                                <option value="Cont4" class="textsmallred">&raquo; &#1062;&#1077;&#1085;&#1090;&#1088;&#1072;&#1083;&#1100;&#1085;&#1072;&#1103; &#1040;&#1084;&#1077;&#1088;&#1080;&#1082;&#1072;</option>
                                
                                <option value="Belize">&nbsp;&#1041;&#1077;&#1083;&#1080;&#1079; (1)</option>
                                
                                <option value="Costa Rica">&nbsp;&#1050;&#1086;&#1089;&#1090;&#1072;-&#1056;&#1080;&#1082;&#1072; (3)</option>
                                
                                <option value="Panama">&nbsp;&#1055;&#1072;&#1085;&#1072;&#1084;&#1072; (7)</option>
                                
                                <option value="Cont10" class="textsmallred">&raquo; &#1070;&#1078;&#1085;&#1072;&#1103; &#1040;&#1084;&#1077;&#1088;&#1080;&#1082;&#1072;</option>
                                
                                <option value="Argentina">&nbsp;&#1040;&#1088;&#1075;&#1077;&#1085;&#1090;&#1080;&#1085;&#1072; (2)</option>
                                
                                <option value="Brazil">&nbsp;&#1041;&#1088;&#1072;&#1079;&#1080;&#1083;&#1080;&#1103; (256)</option>
                                
                                <option value="Colombia">&nbsp;&#1050;&#1086;&#1083;&#1091;&#1084;&#1073;&#1080;&#1103; (1)</option>
                                
                                <option value="Venezuela">&nbsp;&#1042;&#1077;&#1085;&#1077;&#1089;&#1091;&#1101;&#1083;&#1072; (1)</option>
                                
                                <option value="Cont7" class="textsmallred">&raquo; &#1041;&#1083;&#1080;&#1078;&#1085;&#1080;&#1081; &#1042;&#1086;&#1089;&#1090;&#1086;&#1082;</option>
                                
                                <option value="Egypt">&nbsp;&#1045;&#1075;&#1080;&#1087;&#1077;&#1090; (133)</option>
                                
                                <option value="U.A.E.">&nbsp;&#1040;&#1088;&#1072;&#1073;&#1089;&#1082;&#1080;&#1077; &#1069;&#1084;&#1080;&#1088;&#1072;&#1090;&#1099; (2367)</option>
                                
                                <option value="Cont11" class="textsmallred">&raquo; &#1070;&#1075;&#1086;-&#1042;&#1086;&#1089;&#1090;&#1086;&#1095;&#1085;&#1072;&#1103; &#1040;&#1079;&#1080;&#1103;</option>
                                
                                <option value="China RP">&nbsp;&#1050;&#1080;&#1090;&#1072;&#1081; &#1056;&#1055; (2)</option>
                                
                                <option value="Indonesia">&nbsp;&#1048;&#1085;&#1076;&#1086;&#1085;&#1077;&#1079;&#1080;&#1103; (3)</option>
                                
                                <option value="Malaysia">&nbsp;&#1052;&#1072;&#1083;&#1072;&#1081;&#1079;&#1080;&#1103; (2)</option>
                                
                                <option value="Philippines">&nbsp;&#1060;&#1080;&#1083;&#1080;&#1087;&#1087;&#1080;&#1085;&#1099; (2)</option>
                                
                                <option value="Thailand">&nbsp;&#1058;&#1072;&#1080;&#1083;&#1072;&#1085;&#1076; (2169)</option>
                                
                                <option value="Vietnam">&nbsp;&#1042;&#1100;&#1077;&#1090;&#1085;&#1072;&#1084; (7)</option>
                                
                                <option value="Cont1" class="textsmallred">&raquo; &#1040;&#1092;&#1088;&#1080;&#1082;&#1072;</option>
                                
                                <option value="Cape Verde">&nbsp;&#1050;&#1072;&#1073;&#1086;-&#1042;&#1077;&#1088;&#1076;&#1077; (87)</option>
                                
                                <option value="Seychelles">&nbsp;&#1057;&#1077;&#1081;&#1096;&#1077;&#1083;&#1100;&#1089;&#1082;&#1080;&#1077; &#1054;&#1089;&#1090;&#1088;&#1086;&#1074;&#1072; (1)</option>
                                
                                <option value="South Africa">&nbsp;&#1070;&#1078;&#1085;&#1072;&#1103; &#1040;&#1092;&#1088;&#1080;&#1082;&#1072; (19)</option>
                                
                                <option value="Tunisia">&nbsp;&#1058;&#1091;&#1085;&#1080;&#1089; (252)</option>
                                
                                <option value="Cont2" class="textsmallred">&raquo; &#1040;&#1079;&#1080;&#1103;</option>
                                
                                <option value="India">&nbsp;&#1048;&#1085;&#1076;&#1080;&#1103; (1)</option>
                                
                                <option value="Cont9" class="textsmallred">&raquo; &#1057;&#1077;&#1074;&#1077;&#1088;</option>
                                
                                <option value="Greenland">&nbsp;&#1043;&#1088;&#1077;&#1085;&#1083;&#1072;&#1085;&#1076;&#1080;&#1103; (1)</option>
                                
            </select>
</div>									
<div class="label">
&#1056;&#1077;&#1075;&#1080;&#1086;&#1085;:
</div>
<div class="searchitem">					
	
                                <select name="srg" class="textsmall" tabindex=24 onChange="regselectedsale()" style="width:154px">
                                  <option value="">
                                  &#1051;&#1102;&#1073;&#1086;&#1080;
                                  </option>
                                </select>
                                
	</div>
<div class="label">
&#1043;&#1086;&#1088;&#1086;&#1076;:
</div>
<div class="searchitem">

                            <div id="citytxt"><input class="text-1" type="text" name="txtCityOrTown" style="width:149px" maxlength="50" value=""></div>
                            <div id="citydrp" style="display:none"><select name="sltcity" id="sltcity" class="textsmall" style="width:154px">
                                <option value="">&#1051;&#1102;&#1073;&#1086;&#1080;</option>
                              </select></div>
                            
</div>
<div class="label">
&#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1099;&#1077;:
</div>
<div class="searchitem">
<select name="sltptype" class="textsmall" style="width:154px">
            <option value="">&#1051;&#1102;&#1073;&#1086;&#1080;</option>
            
			<option value="Villa-House">&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;</option>


			<option value="Country-House">&#1079;&#1072;&#1075;&#1086;&#1088;&#1086;&#1076;&#1085;&#1099;&#1077; &#1076;&#1086;&#1084;&#1072;</option>


			<option value="Apartment">&#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1099;</option>


			<option value="Farmhouse">&#1092;&#1077;&#1088;&#1084;&#1099;</option>


			<option value="Cottage">&#1082;&#1086;&#1090;&#1090;&#1077;&#1076;&#1078;&#1080;</option>


			<option value="Cabin">&#1076;&#1077;&#1088;&#1077;&#1074;&#1103;&#1085;&#1085;&#1099;&#1077; &#1076;&#1086;&#1084;&#1072;</option>


			<option value="Chalet">&#1096;&#1072;&#1083;&#1077;</option>


			<option value="Townhouse">&#1090;&#1072;&#1091;&#1085;-&#1093;&#1072;&#1091;&#1089;&#1099;</option>


			<option value="Chateau-Castle">&#1047;&#1072;&#1084;&#1086;&#1082;</option>


			<option value="Condo">&#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1085;&#1099;&#1077; &#1076;&#1086;&#1084;&#1072;</option>


			<option value="Finca">&#1087;&#1083;&#1072;&#1085;&#1090;&#1072;&#1094;&#1080;&#1080;</option>


			<option value="Houseboat">&#1087;&#1083;&#1072;&#1074;&#1091;&#1095;&#1080;&#1077; &#1076;&#1086;&#1084;&#1072;</option>


			<option value="Land-Plot">&#1079;&#1077;&#1084;&#1077;&#1083;&#1100;&#1085;&#1099;&#1077; &#1091;&#1095;&#1072;&#1089;&#1090;&#1082;&#1080;</option>


			<option value="Hotel">&#1075;&#1086;&#1089;&#1090;&#1080;&#1085;&#1080;&#1094;&#1099;</option>


			<option value="Bar-Restaurant">&#1073;&#1072;&#1088;&#1099;-&#1088;&#1077;&#1089;&#1090;&#1086;&#1088;&#1072;&#1085;&#1099;</option>


			<option value="Commercial-Retail">&#1082;&#1086;&#1084;&#1084;&#1077;&#1088;&#1095;&#1077;&#1089;&#1082;&#1072;&#1103;</option>


        </select>
</div>
<div class="label">
&#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;:
</div>
<div class="searchitem">
<select name="sltbedrooms" class="textsmall">
            <option value="">&#1051;&#1102;&#1073;&#1086;&#1080;</option>
            
			<option value="0">&#1057;&#1090;&#1091;&#1076;&#1080;&#1103;</option>


			<option value="1">1</option>


			<option value="1 or more">&#1041;&#1086;&#1083;&#1100;&#1096;&#1077; 1</option>


			<option value="2">2</option>


			<option value="2 or more">&#1041;&#1086;&#1083;&#1100;&#1096;&#1077; 2</option>


			<option value="3">3</option>


			<option value="3 or more">&#1041;&#1086;&#1083;&#1100;&#1096;&#1077; 3</option>


			<option value="4">4</option>


			<option value="4 or more">&#1041;&#1086;&#1083;&#1100;&#1096;&#1077; 4</option>


			<option value="5">5</option>


			<option value="5 or more">&#1041;&#1086;&#1083;&#1100;&#1096;&#1077; 5</option>


			<option value="10 or more">&#1041;&#1086;&#1083;&#1100;&#1096;&#1077; 10</option>


			<option value="20 or more">&#1041;&#1086;&#1083;&#1100;&#1096;&#1077; 20</option>


			<option value="30 or more">&#1041;&#1086;&#1083;&#1100;&#1096;&#1077; 30</option>


			<option value="40 or more">&#1041;&#1086;&#1083;&#1100;&#1096;&#1077; 40</option>


			<option value="50 or more">&#1041;&#1086;&#1083;&#1100;&#1096;&#1077; 50</option>


          </select>
</div>
<div class="label">
&#1041;&#1072;&#1089;&#1089;&#1077;&#1080;&#774;&#1085;:
</div>
<div class="searchitem">
<select name="sltpool" class="textsmall">
            
	<option value="">&#1083;&#1102;&#1073;&#1086;&#1081;</option>

		<option value="Yes">&#1076;&#1072;</option>

		<option value="No">&#1085;&#1077;&#1090;</option>

        </select>
</div>
<div class="label">
&#1085;&#1077;&#1076;&#1074;&#1080;&#1078;:
</div>
<div class="searchitem">
<select name="sltpricerange" class="textsmall" style="width:154px">
            <option value="">&#1051;&#1102;&#1073;&#1086;&#1080;</option>
            
	<option value="0">&#1052;&#1077;&#1085;&#1100;&#1096;&#1077; 100,000</option>

	<option value="1">100,000 to 150,000</option>

	<option value="2">150,001 to 200,000</option>

	<option value="3">200,001 to 250,000</option>

	<option value="4">250,001 to 300,000</option>

	<option value="5">300,001 to 350,000</option>

	<option value="6">350,001 to 400,000</option>

	<option value="7">400,001 to 500,000</option>

	<option value="8">500,001 to 600,000</option>

	<option value="9">600,001 to 800,000</option>

	<option value="10">800,001 to 1,000,000</option>

	<option value="11">&#1041;&#1086;&#1083;&#1100;&#1096;&#1077; 1,000,000</option>

          </select>
</div>
	<div id="currency">
            <input type="radio" name="ctype" value="Euro" checked>
          &euro; Euro
          <input type="radio" name="ctype" value="Dollar" >
          $ USD
          <input type="radio" name="ctype" value="GBP" >
          &pound; GBP </div>
		  <div id="search-butt">
            <input type="Submit" value="&#1053;&#1072;&#1095;&#1072;&#1090;&#1100; &#1087;&#1086;&#1080;&#1089;&#1082;" name="Submit" class="copyright" onClick="return CheckForm()" title="&#1053;&#1072;&#1095;&#1072;&#1090;&#1100; &#1087;&#1086;&#1080;&#1089;&#1082;">
             <br>
<div id="pub_loading" align="center">
	<div id="floatingBarsG">
		<div class="blockG" id="rotateG_01">
		</div>
		<div class="blockG" id="rotateG_02">
		</div>
		<div class="blockG" id="rotateG_03">
		</div>
		<div class="blockG" id="rotateG_04">
		</div>
		<div class="blockG" id="rotateG_05">
		</div>
		<div class="blockG" id="rotateG_06">
		</div>
		<div class="blockG" id="rotateG_07">
		</div>
		<div class="blockG" id="rotateG_08">
		</div>
	</div>
</div>
</div>		  
</form>
</div>
<div class="searchboxR">
	   <div align="center" class="search-white" style="padding-top:6px">
                                        156 826 &#1086;&#1073;&#1098;&#1077;&#1082;&#1090;&#1086;&#1074; &#1076;&#1083;&#1103; &#1072;&#1088;&#1077;&#1085;&#1076;&#1099;</div>
	   <div align="center" class="textsmall" style="padding-top:6px">
	  <select name="scr" class="textsmall" onChange="MM_jumpMenu('parent',this,0);return show_loading22();" style="width:170px">
                        <option value="">&#1042;&#1099;&#1073;&#1077;&#1088;&#1080;&#1090;&#1077; &#1089;&#1090;&#1088;&#1072;&#1085;&#1091;</option>
                            
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Cont6.htm" class="textsmallred">&raquo; &#1045;&#1074;&#1088;&#1086;&#1087;&#1072;</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Albania.htm" class="textsmall">&#1040;&#1083;&#1073;&#1072;&#1085;&#1080;&#1103; (79)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Andorra.htm" class="textsmall">&#1040;&#1085;&#1076;&#1086;&#1088;&#1088;&#1072; (12)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Austria.htm" class="textsmall">&#1040;&#1074;&#1089;&#1090;&#1088;&#1080;&#1103; (277)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Belgium.htm" class="textsmall">&#1041;&#1077;&#1083;&#1100;&#1075;&#1080;&#1103; (106)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Bosnia.htm" class="textsmall">&#1041;&#1086;&#1089;&#1085;&#1080;&#1103; (27)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Bulgaria.htm" class="textsmall">&#1041;&#1086;&#1083;&#1075;&#1072;&#1088;&#1080;&#1103; (136)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Croatia.htm" class="textsmall">&#1061;&#1086;&#1088;&#1074;&#1072;&#1090;&#1080;&#1103; (5300)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Cyprus.htm" class="textsmall">&#1050;&#1080;&#1087;&#1088; (410)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Czech+Republic.htm" class="textsmall">&#1063;&#1077;&#1093;&#1080;&#1103; (199)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Denmark.htm" class="textsmall">&#1044;&#1072;&#1085;&#1080;&#1103; (1033)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~England.htm" class="textsmall">&#1040;&#1085;&#1075;&#1083;&#1080;&#1103; (2836)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Estonia.htm" class="textsmall">&#1069;&#1089;&#1090;&#1086;&#1085;&#1080;&#1103; (56)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Faroe+Islands.htm" class="textsmall">&#1060;&#1072;&#1088;&#1077;&#1088;&#1089;&#1082;&#1080;&#1077; &#1086;&#1089;&#1090;&#1088;&#1086;&#1074;&#1072; (3)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Finland.htm" class="textsmall">&#1060;&#1080;&#1085;&#1083;&#1103;&#1085;&#1076;&#1080;&#1103; (39)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~France.htm" class="textsmall">&#1060;&#1088;&#1072;&#1085;&#1094;&#1080;&#1103; (2858)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Georgia.htm" class="textsmall">&#1043;&#1088;&#1091;&#1079;&#1080;&#1103; (28)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Germany.htm" class="textsmall">&#1043;&#1077;&#1088;&#1084;&#1072;&#1085;&#1080;&#1103; (3257)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Gibraltar.htm" class="textsmall">&#1043;&#1080;&#1073;&#1088;&#1072;&#1083;&#1090;&#1072;&#1088; (2)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Greece.htm" class="textsmall">&#1043;&#1088;&#1077;&#1094;&#1080;&#1103; (1663)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Hungary.htm" class="textsmall">&#1042;&#1077;&#1085;&#1075;&#1088;&#1080;&#1103; (298)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Iceland.htm" class="textsmall">&#1048;&#1089;&#1083;&#1072;&#1085;&#1076;&#1080;&#1103; (308)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Ireland-North.htm" class="textsmall">&#1048;&#1088;&#1083;&#1072;&#1085;&#1076;&#1080;&#1103;-&#1057;&#1077;&#1074;&#1077;&#1088;&#1085;&#1072;&#1103; (47)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Ireland-South.htm" class="textsmall">&#1048;&#1088;&#1083;&#1072;&#1085;&#1076;&#1080;&#1103;-&#1070;&#1075; (411)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Isle+of+Man.htm" class="textsmall">&#1054;&#1089;&#1090;&#1088;&#1086;&#1074; &#1052;&#1101;&#1085; (2)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Italy.htm" class="textsmall">&#1048;&#1090;&#1072;&#1083;&#1080;&#1103; (14031)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Latvia.htm" class="textsmall">&#1051;&#1072;&#1090;&#1074;&#1080;&#1103; (19)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Lithuania.htm" class="textsmall">&#1051;&#1080;&#1090;&#1074;&#1072; (30)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Macedonia.htm" class="textsmall">&#1052;&#1072;&#1082;&#1077;&#1076;&#1086;&#1085;&#1080;&#1103; (12)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Malta.htm" class="textsmall">&#1052;&#1072;&#1083;&#1100;&#1090;&#1072; (190)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Moldova.htm" class="textsmall">&#1052;&#1086;&#1083;&#1076;&#1086;&#1074;&#1072; (5)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Monaco.htm" class="textsmall">&#1052;&#1086;&#1085;&#1072;&#1082;&#1086; (3)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Montenegro.htm" class="textsmall">&#1063;&#1077;&#1088;&#1085;&#1086;&#1075;&#1086;&#1088;&#1080;&#1103; (153)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Netherlands.htm" class="textsmall">&#1053;&#1080;&#1076;&#1077;&#1088;&#1083;&#1072;&#1085;&#1076;&#1099; (258)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Norway.htm" class="textsmall">&#1053;&#1086;&#1088;&#1074;&#1077;&#1075;&#1080;&#1103; (28)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Poland.htm" class="textsmall">&#1055;&#1086;&#1083;&#1100;&#1096;&#1072; (123)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Portugal.htm" class="textsmall">&#1055;&#1086;&#1088;&#1090;&#1091;&#1075;&#1072;&#1083;&#1080;&#1103; (1452)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Romania.htm" class="textsmall">&#1056;&#1091;&#1084;&#1099;&#1085;&#1080;&#1103; (144)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Russia.htm" class="textsmall">&#1056;&#1086;&#1089;&#1089;&#1080;&#1103; (72)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Scotland.htm" class="textsmall">&#1064;&#1086;&#1090;&#1083;&#1072;&#1085;&#1076;&#1080;&#1103; (670)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Serbia.htm" class="textsmall">&#1057;&#1077;&#1088;&#1073;&#1080;&#1103; (122)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Slovakia.htm" class="textsmall">&#1057;&#1083;&#1086;&#1074;&#1072;&#1082;&#1080;&#1103; (18)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Slovenia.htm" class="textsmall">&#1057;&#1083;&#1086;&#1074;&#1077;&#1085;&#1080;&#1103; (150)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Spain.htm" class="textsmall">&#1048;&#1089;&#1087;&#1072;&#1085;&#1080;&#1103; (4325)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Sweden.htm" class="textsmall">&#1064;&#1074;&#1077;&#1094;&#1080;&#1103; (31)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Switzerland.htm" class="textsmall">&#1064;&#1074;&#1077;&#1081;&#1094;&#1072;&#1088;&#1080;&#1103; (145)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Turkey.htm" class="textsmall">&#1058;&#1091;&#1088;&#1094;&#1080;&#1103; (623)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Ukrainia.htm" class="textsmall">&#1059;&#1082;&#1088;&#1072;&#1080;&#1085;&#1089;&#1082;&#1080;&#1081; (249)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Wales.htm" class="textsmall">&#1059;&#1101;&#1083;&#1100;&#1089; (804)</option>
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Cont8.htm" class="textsmallred">&raquo; &#1057;&#1077;&#1074;&#1077;&#1088;&#1085;&#1072;&#1103; &#1040;&#1084;&#1077;&#1088;&#1080;&#1082;&#1072;</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Canada.htm" class="textsmall">&#1050;&#1072;&#1085;&#1072;&#1076;&#1072; (4246)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Mexico.htm" class="textsmall">&#1052;&#1077;&#1082;&#1089;&#1080;&#1082;&#1072; (3424)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~USA.htm" class="textsmall">&#1040;&#1084;&#1077;&#1088;&#1080;&#1082;&#1072; (48656)</option>
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Cont5.htm" class="textsmallred">&raquo; &#1050;&#1072;&#1088;&#1080;&#1073;&#1089;&#1082;&#1080;&#1081;</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Anguilla.htm" class="textsmall">&#1040;&#1085;&#1075;&#1080;&#1083;&#1100;&#1103; (217)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Antigua-Barbuda.htm" class="textsmall">&#1040;&#1085;&#1090;&#1080;&#1075;&#1091;&#1072; &#1080; &#1041;&#1072;&#1088;&#1073;&#1091;&#1076;&#1072; (168)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Aruba.htm" class="textsmall">&#1040;&#1088;&#1091;&#1073;&#1072; (45)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Bahamas.htm" class="textsmall">&#1041;&#1072;&#1075;&#1072;&#1084;&#1089;&#1082;&#1080;&#1077; &#1054;&#1089;&#1090;&#1088;&#1086;&#1074;&#1072; (327)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Barbados.htm" class="textsmall">&#1041;&#1072;&#1088;&#1073;&#1072;&#1076;&#1086;&#1089; (6490)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Bermuda-Atlantic.htm" class="textsmall">&#1041;&#1077;&#1088;&#1084;&#1091;&#1076;&#1089;&#1082;&#1080;&#1077; &#1040;&#1090;&#1083;&#1072;&#1085;&#1090;&#1080;&#1082;&#1077; (9)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Bonaire.htm" class="textsmall">&#1041;&#1086;&#1085;&#1072;&#1081;&#1088;&#1077; (33)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Cayman+Island.htm" class="textsmall">&#1050;&#1072;&#1081;&#1084;&#1072;&#1085;&#1086;&#1074;&#1099; &#1086;&#1089;&#1090;&#1088;&#1086;&#1074;&#1072; (99)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Curacao.htm" class="textsmall">&#1050;&#1102;&#1088;&#1072;&#1089;&#1072;&#1086; (47)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Dominica+Island.htm" class="textsmall">&#1044;&#1086;&#1084;&#1080;&#1085;&#1080;&#1082;&#1072; &#1086;&#1089;&#1090;&#1088;&#1086;&#1074; (48)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Dominican+Republic.htm" class="textsmall">&#1044;&#1086;&#1084;&#1080;&#1085;&#1080;&#1082;&#1072;&#1085;&#1089;&#1082;&#1072;&#1103; &#1056;&#1077;&#1089;&#1087;&#1091;&#1073;&#1083;&#1080;&#1082;&#1072; (759)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~French+Indies.htm" class="textsmall">&#1060;&#1088;&#1072;&#1085;&#1094;&#1091;&#1079;&#1089;&#1082;&#1080;&#1081; &#1048;&#1085;&#1076;&#1080;&#1080; (809)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Grenada-Carriacou.htm" class="textsmall">&#1043;&#1088;&#1077;&#1085;&#1072;&#1076;&#1072;-Cardiacudu (36)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Guadeloupe.htm" class="textsmall">&#1043;&#1074;&#1072;&#1076;&#1077;&#1083;&#1091;&#1087;&#1072; (28)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Haiti.htm" class="textsmall">&#1043;&#1072;&#1080;&#1090;&#1080; (2)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Jamaica.htm" class="textsmall">&#1071;&#1084;&#1072;&#1081;&#1082;&#1072; (470)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Martinique.htm" class="textsmall">&#1052;&#1072;&#1088;&#1090;&#1080;&#1085;&#1080;&#1082;&#1072; (25)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Montserrat.htm" class="textsmall">&#1052;&#1086;&#1085;&#1090;&#1089;&#1077;&#1088;&#1088;&#1072;&#1090; (9)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Netherlands-Antilles.htm" class="textsmall">&#1040;&#1085;&#1090;&#1080;&#1083;&#1100;&#1089;&#1082;&#1080;&#1077; &#1086;&#1089;&#1090;&#1088;&#1086;&#1074;&#1072; (80)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Puerto+Rico.htm" class="textsmall">&#1055;&#1091;&#1101;&#1088;&#1090;&#1086;-&#1056;&#1080;&#1082;&#1086; (401)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Saba.htm" class="textsmall">&#1057;&#1072;&#1073;&#1099; (7)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~St.+Barthelemy.htm" class="textsmall">&#1057;&#1077;&#1085;-&#1041;&#1072;&#1088;&#1090;&#1077;&#1083;&#1100;&#1084;&#1080; (185)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~St.+Kitts-Nevis.htm" class="textsmall">&#1057;&#1077;&#1085;&#1090;-&#1050;&#1080;&#1090;&#1089;-&#1053;&#1077;&#1074;&#1080;&#1089; (47)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~St.+Lucia.htm" class="textsmall">&#1057;&#1077;&#1085;&#1090;-&#1051;&#1102;&#1089;&#1080;&#1103; (154)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~St.+Maarten.htm" class="textsmall">&#1057;&#1077;&#1085;-&#1052;&#1072;&#1088;&#1090;&#1077;&#1085; (297)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~St.+Martin.htm" class="textsmall">&#1057;&#1077;&#1085;-&#1052;&#1072;&#1088;&#1090;&#1077;&#1085; (397)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~St.+Vincent-Grenadines.htm" class="textsmall">&#1057;&#1077;&#1085;&#1090;-&#1042;&#1080;&#1085;&#1089;&#1077;&#1085;&#1090;-Granadines (123)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Trinidad-Tobago.htm" class="textsmall">&#1058;&#1088;&#1080;&#1085;&#1080;&#1076;&#1072;&#1076; &#1080; &#1058;&#1086;&#1073;&#1072;&#1075;&#1086; (16)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Turks-Caicos.htm" class="textsmall">&#1058;&#1091;&#1088;&#1086;&#1082;-&#1050;&#1072;&#1081;&#1082;&#1086;&#1089; (211)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Virgin+Islands+UK.htm" class="textsmall">&#1042;&#1080;&#1088;&#1075;&#1080;&#1085;&#1089;&#1082;&#1080;&#1077; &#1086;&#1089;&#1090;&#1088;&#1086;&#1074;&#1072; UK (224)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Virgin+Islands+US.htm" class="textsmall">&#1042;&#1080;&#1088;&#1075;&#1080;&#1085;&#1089;&#1082;&#1080;&#1077; &#1086;&#1089;&#1090;&#1088;&#1086;&#1074;&#1072; US (1109)</option>
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Cont3.htm" class="textsmallred">&raquo; &#1040;&#1074;&#1089;&#1090;&#1088;&#1072;&#1083;&#1080;&#1103;T&#1080;&#1093;&#1080;&#1081; &#1086;&#1082;&#1077;&#1072;&#1085;</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Australia.htm" class="textsmall">&#1040;&#1074;&#1089;&#1090;&#1088;&#1072;&#1083;&#1080;&#1103; (1215)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Cook+Islands.htm" class="textsmall">&#1054;&#1089;&#1090;&#1088;&#1086;&#1074;&#1072; &#1050;&#1091;&#1082;&#1072; (29)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Fiji.htm" class="textsmall">&#1060;&#1080;&#1076;&#1078;&#1080; (21)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~New+Zealand.htm" class="textsmall">&#1053;&#1086;&#1074;&#1072;&#1103; &#1047;&#1077;&#1083;&#1072;&#1085;&#1076;&#1080;&#1103; (488)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Vanuatu.htm" class="textsmall">&#1042;&#1072;&#1085;&#1091;&#1072;&#1090;&#1091; (30)</option>
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Cont4.htm" class="textsmallred">&raquo; &#1062;&#1077;&#1085;&#1090;&#1088;&#1072;&#1083;&#1100;&#1085;&#1072;&#1103; &#1040;&#1084;&#1077;&#1088;&#1080;&#1082;&#1072;</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Belize.htm" class="textsmall">&#1041;&#1077;&#1083;&#1080;&#1079; (171)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Costa+Rica.htm" class="textsmall">&#1050;&#1086;&#1089;&#1090;&#1072;-&#1056;&#1080;&#1082;&#1072; (1377)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Cuba.htm" class="textsmall">&#1050;&#1091;&#1073;&#1072; (2)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Guatemala.htm" class="textsmall">&#1043;&#1074;&#1072;&#1090;&#1077;&#1084;&#1072;&#1083;&#1072; (53)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Honduras.htm" class="textsmall">&#1043;&#1086;&#1085;&#1076;&#1091;&#1088;&#1072;&#1089; (69)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Nicaragua.htm" class="textsmall">&#1053;&#1080;&#1082;&#1072;&#1088;&#1072;&#1075;&#1091;&#1072; (86)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Panama.htm" class="textsmall">&#1055;&#1072;&#1085;&#1072;&#1084;&#1072; (162)</option>
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Cont10.htm" class="textsmallred">&raquo; &#1070;&#1078;&#1085;&#1072;&#1103; &#1040;&#1084;&#1077;&#1088;&#1080;&#1082;&#1072;</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Argentina.htm" class="textsmall">&#1040;&#1088;&#1075;&#1077;&#1085;&#1090;&#1080;&#1085;&#1072; (747)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Bolivia.htm" class="textsmall">&#1041;&#1086;&#1083;&#1080;&#1074;&#1080;&#1103; (4)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Brazil.htm" class="textsmall">&#1041;&#1088;&#1072;&#1079;&#1080;&#1083;&#1080;&#1103; (1028)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Colombia.htm" class="textsmall">&#1050;&#1086;&#1083;&#1091;&#1084;&#1073;&#1080;&#1103; (203)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Chile.htm" class="textsmall">&#1063;&#1080;&#1083;&#1080; (139)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Peru.htm" class="textsmall">&#1055;&#1077;&#1088;&#1091; (196)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Uruguay.htm" class="textsmall">&#1059;&#1088;&#1091;&#1075;&#1074;&#1072;&#1081; (93)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Venezuela.htm" class="textsmall">&#1042;&#1077;&#1085;&#1077;&#1089;&#1091;&#1101;&#1083;&#1072; (11)</option>
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Cont7.htm" class="textsmallred">&raquo; &#1041;&#1083;&#1080;&#1078;&#1085;&#1080;&#1081; &#1042;&#1086;&#1089;&#1090;&#1086;&#1082;</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Egypt.htm" class="textsmall">&#1045;&#1075;&#1080;&#1087;&#1077;&#1090; (62)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Iraq.htm" class="textsmall">&#1048;&#1088;&#1072;&#1082; (1)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Israel.htm" class="textsmall">&#1048;&#1079;&#1088;&#1072;&#1080;&#1083;&#1100; (597)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Jordan.htm" class="textsmall">&#1048;&#1086;&#1088;&#1076;&#1072;&#1085;&#1080;&#1103; (6)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Lebanon.htm" class="textsmall">&#1051;&#1080;&#1074;&#1072;&#1085; (5)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Oman.htm" class="textsmall">&#1054;&#1084;&#1072;&#1085; (2)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~U.A.E..htm" class="textsmall">&#1040;&#1088;&#1072;&#1073;&#1089;&#1082;&#1080;&#1077; &#1069;&#1084;&#1080;&#1088;&#1072;&#1090;&#1099; (143)</option>
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Cont11.htm" class="textsmallred">&raquo; &#1070;&#1075;&#1086;-&#1042;&#1086;&#1089;&#1090;&#1086;&#1095;&#1085;&#1072;&#1103; &#1040;&#1079;&#1080;&#1103;</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Cambodia.htm" class="textsmall">&#1050;&#1072;&#1084;&#1073;&#1086;&#1076;&#1078;&#1072; (17)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~China+RP.htm" class="textsmall">&#1050;&#1080;&#1090;&#1072;&#1081; &#1056;&#1055; (51)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Indonesia.htm" class="textsmall">&#1048;&#1085;&#1076;&#1086;&#1085;&#1077;&#1079;&#1080;&#1103; (2246)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Japan.htm" class="textsmall">&#1071;&#1087;&#1086;&#1085;&#1080;&#1103; (159)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Macau.htm" class="textsmall">&#1052;&#1072;&#1082;&#1072;&#1086; (1)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Malaysia.htm" class="textsmall">&#1052;&#1072;&#1083;&#1072;&#1081;&#1079;&#1080;&#1103; (187)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Nepal.htm" class="textsmall">&#1053;&#1077;&#1087;&#1072;&#1083; (19)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Philippines.htm" class="textsmall">&#1060;&#1080;&#1083;&#1080;&#1087;&#1087;&#1080;&#1085;&#1099; (444)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Singapore.htm" class="textsmall">&#1057;&#1080;&#1085;&#1075;&#1072;&#1087;&#1091;&#1088; (16)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Taiwan.htm" class="textsmall">&#1058;&#1072;&#1081;&#1074;&#1072;&#1085;&#1100; (18)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Thailand.htm" class="textsmall">&#1058;&#1072;&#1080;&#1083;&#1072;&#1085;&#1076; (2159)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Vietnam.htm" class="textsmall">&#1042;&#1100;&#1077;&#1090;&#1085;&#1072;&#1084; (46)</option>
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Cont1.htm" class="textsmallred">&raquo; &#1040;&#1092;&#1088;&#1080;&#1082;&#1072;</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Cape+Verde.htm" class="textsmall">&#1050;&#1072;&#1073;&#1086;-&#1042;&#1077;&#1088;&#1076;&#1077; (16)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Kenya.htm" class="textsmall">&#1050;&#1077;&#1085;&#1080;&#1103; (157)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Lesotho.htm" class="textsmall">&#1051;&#1077;&#1089;&#1086;&#1090;&#1086; (2)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Madagascar.htm" class="textsmall">&#1052;&#1072;&#1076;&#1072;&#1075;&#1072;&#1089;&#1082;&#1072;&#1088; (2)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Mauritius.htm" class="textsmall">&#1052;&#1072;&#1074;&#1088;&#1080;&#1082;&#1080;&#1081; (71)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Morocco.htm" class="textsmall">&#1052;&#1072;&#1088;&#1086;&#1082;&#1082;&#1086; (181)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Namibia.htm" class="textsmall">&#1053;&#1072;&#1084;&#1080;&#1073;&#1080;&#1103; (11)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Senegal.htm" class="textsmall">&#1057;&#1077;&#1085;&#1077;&#1075;&#1072;&#1083; (7)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Seychelles.htm" class="textsmall">&#1057;&#1077;&#1081;&#1096;&#1077;&#1083;&#1100;&#1089;&#1082;&#1080;&#1077; &#1054;&#1089;&#1090;&#1088;&#1086;&#1074;&#1072; (33)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~South+Africa.htm" class="textsmall">&#1070;&#1078;&#1085;&#1072;&#1103; &#1040;&#1092;&#1088;&#1080;&#1082;&#1072; (933)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Tanzania.htm" class="textsmall">&#1058;&#1072;&#1085;&#1079;&#1072;&#1085;&#1080;&#1103; (24)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Tunisia.htm" class="textsmall">&#1058;&#1091;&#1085;&#1080;&#1089; (28)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Uganda.htm" class="textsmall">&#1059;&#1075;&#1072;&#1085;&#1076;&#1072; (12)</option>
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Cont2.htm" class="textsmallred">&raquo; &#1040;&#1079;&#1080;&#1103;</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Bangladesh.htm" class="textsmall">&#1041;&#1072;&#1085;&#1075;&#1083;&#1072;&#1076;&#1077;&#1096; (5)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~India.htm" class="textsmall">&#1048;&#1085;&#1076;&#1080;&#1103; (483)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Maldives.htm" class="textsmall">&#1052;&#1072;&#1083;&#1100;&#1076;&#1080;&#1074;&#1099; (12)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Pakistan.htm" class="textsmall">&#1055;&#1072;&#1082;&#1080;&#1089;&#1090;&#1072;&#1085; (2)</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Sri+Lanka.htm" class="textsmall">&#1064;&#1088;&#1080;-&#1051;&#1072;&#1085;&#1082;&#1072; (300)</option>
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Cont9.htm" class="textsmallred">&raquo; &#1057;&#1077;&#1074;&#1077;&#1088;</option>
                        
                        
                        <option value="http://www.holprop.ru/holiday_rentals~scr~Greenland.htm" class="textsmall">&#1043;&#1088;&#1077;&#1085;&#1083;&#1072;&#1085;&#1076;&#1080;&#1103; (2)</option>
                        
          </select>
<div id="pub_loading22">
	<div id="floatingBarsG">
		<div class="blockG" id="rotateG_01">
		</div>
		<div class="blockG" id="rotateG_02">
		</div>
		<div class="blockG" id="rotateG_03">
		</div>
		<div class="blockG" id="rotateG_04">
		</div>
		<div class="blockG" id="rotateG_05">
		</div>
		<div class="blockG" id="rotateG_06">
		</div>
		<div class="blockG" id="rotateG_07">
		</div>
		<div class="blockG" id="rotateG_08">
		</div>
	</div>
</div>
	</div>
</div>
<div class="searchboxR">
<div align="center" class="search-white" style="padding-top:6px">
                                        46 413 &#1040;&#1088;&#1077;&#1085;&#1076;&#1072; &#1085;&#1072; &#1077;&#1078;&#1077;&#1084;&#1077;&#1089;&#1103;&#1095;&#1085;&#1086;</div>
<div align="center" class="textsmall" style="padding-top:6px">
	  <select name="scr" class="textsmall" onChange="MM_jumpMenu('parent',this,0);return show_loading33();" style="width:170px">
                        <option value="">&#1042;&#1099;&#1073;&#1077;&#1088;&#1080;&#1090;&#1077; &#1089;&#1090;&#1088;&#1072;&#1085;&#1091;</option>
                            
                        <option value="http://www.longtermlettings.com/find/rentals/Cont6/" class="textsmallred">&raquo; &#1045;&#1074;&#1088;&#1086;&#1087;&#1072;</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Albania/" class="textsmall">&#1040;&#1083;&#1073;&#1072;&#1085;&#1080;&#1103; (68)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Andorra/" class="textsmall">&#1040;&#1085;&#1076;&#1086;&#1088;&#1088;&#1072; (4)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Austria/" class="textsmall">&#1040;&#1074;&#1089;&#1090;&#1088;&#1080;&#1103; (94)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Belgium/" class="textsmall">&#1041;&#1077;&#1083;&#1100;&#1075;&#1080;&#1103; (57)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Bosnia/" class="textsmall">&#1041;&#1086;&#1089;&#1085;&#1080;&#1103; (16)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Bulgaria/" class="textsmall">&#1041;&#1086;&#1083;&#1075;&#1072;&#1088;&#1080;&#1103; (75)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Croatia/" class="textsmall">&#1061;&#1086;&#1088;&#1074;&#1072;&#1090;&#1080;&#1103; (3251)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Cyprus/" class="textsmall">&#1050;&#1080;&#1087;&#1088; (151)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Czech_Republic/" class="textsmall">&#1063;&#1077;&#1093;&#1080;&#1103; (105)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Denmark/" class="textsmall">&#1044;&#1072;&#1085;&#1080;&#1103; (9)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/England/" class="textsmall">&#1040;&#1085;&#1075;&#1083;&#1080;&#1103; (329)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Estonia/" class="textsmall">&#1069;&#1089;&#1090;&#1086;&#1085;&#1080;&#1103; (27)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Faroe_Islands/" class="textsmall">&#1060;&#1072;&#1088;&#1077;&#1088;&#1089;&#1082;&#1080;&#1077; &#1086;&#1089;&#1090;&#1088;&#1086;&#1074;&#1072; (1)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Finland/" class="textsmall">&#1060;&#1080;&#1085;&#1083;&#1103;&#1085;&#1076;&#1080;&#1103; (6)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/France/" class="textsmall">&#1060;&#1088;&#1072;&#1085;&#1094;&#1080;&#1103; (821)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Georgia/" class="textsmall">&#1043;&#1088;&#1091;&#1079;&#1080;&#1103; (22)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Germany/" class="textsmall">&#1043;&#1077;&#1088;&#1084;&#1072;&#1085;&#1080;&#1103; (138)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Greece/" class="textsmall">&#1043;&#1088;&#1077;&#1094;&#1080;&#1103; (544)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Hungary/" class="textsmall">&#1042;&#1077;&#1085;&#1075;&#1088;&#1080;&#1103; (135)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Iceland/" class="textsmall">&#1048;&#1089;&#1083;&#1072;&#1085;&#1076;&#1080;&#1103; (17)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Ireland-North/" class="textsmall">&#1048;&#1088;&#1083;&#1072;&#1085;&#1076;&#1080;&#1103;-&#1057;&#1077;&#1074;&#1077;&#1088;&#1085;&#1072;&#1103; (15)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Ireland-South/" class="textsmall">&#1048;&#1088;&#1083;&#1072;&#1085;&#1076;&#1080;&#1103;-&#1070;&#1075; (75)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Italy/" class="textsmall">&#1048;&#1090;&#1072;&#1083;&#1080;&#1103; (2900)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Latvia/" class="textsmall">&#1051;&#1072;&#1090;&#1074;&#1080;&#1103; (11)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Lithuania/" class="textsmall">&#1051;&#1080;&#1090;&#1074;&#1072; (8)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Macedonia/" class="textsmall">&#1052;&#1072;&#1082;&#1077;&#1076;&#1086;&#1085;&#1080;&#1103; (9)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Malta/" class="textsmall">&#1052;&#1072;&#1083;&#1100;&#1090;&#1072; (64)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Moldova/" class="textsmall">&#1052;&#1086;&#1083;&#1076;&#1086;&#1074;&#1072; (2)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Monaco/" class="textsmall">&#1052;&#1086;&#1085;&#1072;&#1082;&#1086; (3)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Montenegro/" class="textsmall">&#1063;&#1077;&#1088;&#1085;&#1086;&#1075;&#1086;&#1088;&#1080;&#1103; (51)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Netherlands/" class="textsmall">&#1053;&#1080;&#1076;&#1077;&#1088;&#1083;&#1072;&#1085;&#1076;&#1099; (99)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Norway/" class="textsmall">&#1053;&#1086;&#1088;&#1074;&#1077;&#1075;&#1080;&#1103; (10)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Poland/" class="textsmall">&#1055;&#1086;&#1083;&#1100;&#1096;&#1072; (69)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Portugal/" class="textsmall">&#1055;&#1086;&#1088;&#1090;&#1091;&#1075;&#1072;&#1083;&#1080;&#1103; (514)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Romania/" class="textsmall">&#1056;&#1091;&#1084;&#1099;&#1085;&#1080;&#1103; (97)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Russia/" class="textsmall">&#1056;&#1086;&#1089;&#1089;&#1080;&#1103; (36)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Scotland/" class="textsmall">&#1064;&#1086;&#1090;&#1083;&#1072;&#1085;&#1076;&#1080;&#1103; (110)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Serbia/" class="textsmall">&#1057;&#1077;&#1088;&#1073;&#1080;&#1103; (89)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Slovakia/" class="textsmall">&#1057;&#1083;&#1086;&#1074;&#1072;&#1082;&#1080;&#1103; (5)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Slovenia/" class="textsmall">&#1057;&#1083;&#1086;&#1074;&#1077;&#1085;&#1080;&#1103; (44)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Spain/" class="textsmall">&#1048;&#1089;&#1087;&#1072;&#1085;&#1080;&#1103; (2344)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Sweden/" class="textsmall">&#1064;&#1074;&#1077;&#1094;&#1080;&#1103; (9)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Switzerland/" class="textsmall">&#1064;&#1074;&#1077;&#1081;&#1094;&#1072;&#1088;&#1080;&#1103; (50)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Turkey/" class="textsmall">&#1058;&#1091;&#1088;&#1094;&#1080;&#1103; (291)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Ukrainia/" class="textsmall">&#1059;&#1082;&#1088;&#1072;&#1080;&#1085;&#1089;&#1082;&#1080;&#1081; (88)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Wales/" class="textsmall">&#1059;&#1101;&#1083;&#1100;&#1089; (36)</option>
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Cont8/" class="textsmallred">&raquo; &#1057;&#1077;&#1074;&#1077;&#1088;&#1085;&#1072;&#1103; &#1040;&#1084;&#1077;&#1088;&#1080;&#1082;&#1072;</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Canada/" class="textsmall">&#1050;&#1072;&#1085;&#1072;&#1076;&#1072; (1358)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Mexico/" class="textsmall">&#1052;&#1077;&#1082;&#1089;&#1080;&#1082;&#1072; (1708)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/USA/" class="textsmall">&#1040;&#1084;&#1077;&#1088;&#1080;&#1082;&#1072; (16996)</option>
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Cont5/" class="textsmallred">&raquo; &#1050;&#1072;&#1088;&#1080;&#1073;&#1089;&#1082;&#1080;&#1081;</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Anguilla/" class="textsmall">&#1040;&#1085;&#1075;&#1080;&#1083;&#1100;&#1103; (71)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Antigua-Barbuda/" class="textsmall">&#1040;&#1085;&#1090;&#1080;&#1075;&#1091;&#1072; &#1080; &#1041;&#1072;&#1088;&#1073;&#1091;&#1076;&#1072; (62)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Aruba/" class="textsmall">&#1040;&#1088;&#1091;&#1073;&#1072; (5)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Bahamas/" class="textsmall">&#1041;&#1072;&#1075;&#1072;&#1084;&#1089;&#1082;&#1080;&#1077; &#1054;&#1089;&#1090;&#1088;&#1086;&#1074;&#1072; (115)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Barbados/" class="textsmall">&#1041;&#1072;&#1088;&#1073;&#1072;&#1076;&#1086;&#1089; (2515)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Bermuda-Atlantic/" class="textsmall">&#1041;&#1077;&#1088;&#1084;&#1091;&#1076;&#1089;&#1082;&#1080;&#1077; &#1040;&#1090;&#1083;&#1072;&#1085;&#1090;&#1080;&#1082;&#1077; (4)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Bonaire/" class="textsmall">&#1041;&#1086;&#1085;&#1072;&#1081;&#1088;&#1077; (14)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Cayman_Island/" class="textsmall">&#1050;&#1072;&#1081;&#1084;&#1072;&#1085;&#1086;&#1074;&#1099; &#1086;&#1089;&#1090;&#1088;&#1086;&#1074;&#1072; (30)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Curacao/" class="textsmall">&#1050;&#1102;&#1088;&#1072;&#1089;&#1072;&#1086; (18)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Dominica_Island/" class="textsmall">&#1044;&#1086;&#1084;&#1080;&#1085;&#1080;&#1082;&#1072; &#1086;&#1089;&#1090;&#1088;&#1086;&#1074; (23)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Dominican_Republic/" class="textsmall">&#1044;&#1086;&#1084;&#1080;&#1085;&#1080;&#1082;&#1072;&#1085;&#1089;&#1082;&#1072;&#1103; &#1056;&#1077;&#1089;&#1087;&#1091;&#1073;&#1083;&#1080;&#1082;&#1072; (489)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/French_Indies/" class="textsmall">&#1060;&#1088;&#1072;&#1085;&#1094;&#1091;&#1079;&#1089;&#1082;&#1080;&#1081; &#1048;&#1085;&#1076;&#1080;&#1080; (374)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Grenada-Carriacou/" class="textsmall">&#1043;&#1088;&#1077;&#1085;&#1072;&#1076;&#1072;-Cardiacudu (14)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Guadeloupe/" class="textsmall">&#1043;&#1074;&#1072;&#1076;&#1077;&#1083;&#1091;&#1087;&#1072; (1)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Haiti/" class="textsmall">&#1043;&#1072;&#1080;&#1090;&#1080; (2)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Jamaica/" class="textsmall">&#1071;&#1084;&#1072;&#1081;&#1082;&#1072; (204)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Martinique/" class="textsmall">&#1052;&#1072;&#1088;&#1090;&#1080;&#1085;&#1080;&#1082;&#1072; (13)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Montserrat/" class="textsmall">&#1052;&#1086;&#1085;&#1090;&#1089;&#1077;&#1088;&#1088;&#1072;&#1090; (4)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Netherlands-Antilles/" class="textsmall">&#1040;&#1085;&#1090;&#1080;&#1083;&#1100;&#1089;&#1082;&#1080;&#1077; &#1086;&#1089;&#1090;&#1088;&#1086;&#1074;&#1072; (77)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Puerto_Rico/" class="textsmall">&#1055;&#1091;&#1101;&#1088;&#1090;&#1086;-&#1056;&#1080;&#1082;&#1086; (205)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Saba/" class="textsmall">&#1057;&#1072;&#1073;&#1099; (1)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/St._Kitts-Nevis/" class="textsmall">&#1057;&#1077;&#1085;&#1090;-&#1050;&#1080;&#1090;&#1089;-&#1053;&#1077;&#1074;&#1080;&#1089; (9)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/St._Lucia/" class="textsmall">&#1057;&#1077;&#1085;&#1090;-&#1051;&#1102;&#1089;&#1080;&#1103; (85)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/St._Maarten/" class="textsmall">&#1057;&#1077;&#1085;-&#1052;&#1072;&#1088;&#1090;&#1077;&#1085; (17)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/St._Martin/" class="textsmall">&#1057;&#1077;&#1085;-&#1052;&#1072;&#1088;&#1090;&#1077;&#1085; (217)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/St._Vincent-Grenadines/" class="textsmall">&#1057;&#1077;&#1085;&#1090;-&#1042;&#1080;&#1085;&#1089;&#1077;&#1085;&#1090;-Granadines (8)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Trinidad-Tobago/" class="textsmall">&#1058;&#1088;&#1080;&#1085;&#1080;&#1076;&#1072;&#1076; &#1080; &#1058;&#1086;&#1073;&#1072;&#1075;&#1086; (5)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Turks-Caicos/" class="textsmall">&#1058;&#1091;&#1088;&#1086;&#1082;-&#1050;&#1072;&#1081;&#1082;&#1086;&#1089; (98)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Virgin_Islands_UK/" class="textsmall">&#1042;&#1080;&#1088;&#1075;&#1080;&#1085;&#1089;&#1082;&#1080;&#1077; &#1086;&#1089;&#1090;&#1088;&#1086;&#1074;&#1072; UK (69)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Virgin_Islands_US/" class="textsmall">&#1042;&#1080;&#1088;&#1075;&#1080;&#1085;&#1089;&#1082;&#1080;&#1077; &#1086;&#1089;&#1090;&#1088;&#1086;&#1074;&#1072; US (813)</option>
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Cont3/" class="textsmallred">&raquo; &#1040;&#1074;&#1089;&#1090;&#1088;&#1072;&#1083;&#1080;&#1103;T&#1080;&#1093;&#1080;&#1081; &#1086;&#1082;&#1077;&#1072;&#1085;</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Australia/" class="textsmall">&#1040;&#1074;&#1089;&#1090;&#1088;&#1072;&#1083;&#1080;&#1103; (483)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Cook_Islands/" class="textsmall">&#1054;&#1089;&#1090;&#1088;&#1086;&#1074;&#1072; &#1050;&#1091;&#1082;&#1072; (6)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Fiji/" class="textsmall">&#1060;&#1080;&#1076;&#1078;&#1080; (11)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/New_Zealand/" class="textsmall">&#1053;&#1086;&#1074;&#1072;&#1103; &#1047;&#1077;&#1083;&#1072;&#1085;&#1076;&#1080;&#1103; (115)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Vanuatu/" class="textsmall">&#1042;&#1072;&#1085;&#1091;&#1072;&#1090;&#1091; (6)</option>
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Cont4/" class="textsmallred">&raquo; &#1062;&#1077;&#1085;&#1090;&#1088;&#1072;&#1083;&#1100;&#1085;&#1072;&#1103; &#1040;&#1084;&#1077;&#1088;&#1080;&#1082;&#1072;</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Belize/" class="textsmall">&#1041;&#1077;&#1083;&#1080;&#1079; (83)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Costa_Rica/" class="textsmall">&#1050;&#1086;&#1089;&#1090;&#1072;-&#1056;&#1080;&#1082;&#1072; (745)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Cuba/" class="textsmall">&#1050;&#1091;&#1073;&#1072; (1)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Guatemala/" class="textsmall">&#1043;&#1074;&#1072;&#1090;&#1077;&#1084;&#1072;&#1083;&#1072; (37)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Honduras/" class="textsmall">&#1043;&#1086;&#1085;&#1076;&#1091;&#1088;&#1072;&#1089; (25)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Nicaragua/" class="textsmall">&#1053;&#1080;&#1082;&#1072;&#1088;&#1072;&#1075;&#1091;&#1072; (54)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Panama/" class="textsmall">&#1055;&#1072;&#1085;&#1072;&#1084;&#1072; (100)</option>
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Cont10/" class="textsmallred">&raquo; &#1070;&#1078;&#1085;&#1072;&#1103; &#1040;&#1084;&#1077;&#1088;&#1080;&#1082;&#1072;</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Argentina/" class="textsmall">&#1040;&#1088;&#1075;&#1077;&#1085;&#1090;&#1080;&#1085;&#1072; (617)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Bolivia/" class="textsmall">&#1041;&#1086;&#1083;&#1080;&#1074;&#1080;&#1103; (2)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Brazil/" class="textsmall">&#1041;&#1088;&#1072;&#1079;&#1080;&#1083;&#1080;&#1103; (499)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Colombia/" class="textsmall">&#1050;&#1086;&#1083;&#1091;&#1084;&#1073;&#1080;&#1103; (123)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Chile/" class="textsmall">&#1063;&#1080;&#1083;&#1080; (84)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Peru/" class="textsmall">&#1055;&#1077;&#1088;&#1091; (131)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Uruguay/" class="textsmall">&#1059;&#1088;&#1091;&#1075;&#1074;&#1072;&#1081; (54)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Venezuela/" class="textsmall">&#1042;&#1077;&#1085;&#1077;&#1089;&#1091;&#1101;&#1083;&#1072; (6)</option>
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Cont7/" class="textsmallred">&raquo; &#1041;&#1083;&#1080;&#1078;&#1085;&#1080;&#1081; &#1042;&#1086;&#1089;&#1090;&#1086;&#1082;</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Egypt/" class="textsmall">&#1045;&#1075;&#1080;&#1087;&#1077;&#1090; (33)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Israel/" class="textsmall">&#1048;&#1079;&#1088;&#1072;&#1080;&#1083;&#1100; (273)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Jordan/" class="textsmall">&#1048;&#1086;&#1088;&#1076;&#1072;&#1085;&#1080;&#1103; (4)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Lebanon/" class="textsmall">&#1051;&#1080;&#1074;&#1072;&#1085; (2)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Oman/" class="textsmall">&#1054;&#1084;&#1072;&#1085; (1)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/U.A.E./" class="textsmall">&#1040;&#1088;&#1072;&#1073;&#1089;&#1082;&#1080;&#1077; &#1069;&#1084;&#1080;&#1088;&#1072;&#1090;&#1099; (461)</option>
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Cont11/" class="textsmallred">&raquo; &#1070;&#1075;&#1086;-&#1042;&#1086;&#1089;&#1090;&#1086;&#1095;&#1085;&#1072;&#1103; &#1040;&#1079;&#1080;&#1103;</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Cambodia/" class="textsmall">&#1050;&#1072;&#1084;&#1073;&#1086;&#1076;&#1078;&#1072; (6)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/China_RP/" class="textsmall">&#1050;&#1080;&#1090;&#1072;&#1081; &#1056;&#1055; (43)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Indonesia/" class="textsmall">&#1048;&#1085;&#1076;&#1086;&#1085;&#1077;&#1079;&#1080;&#1103; (905)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Japan/" class="textsmall">&#1071;&#1087;&#1086;&#1085;&#1080;&#1103; (59)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Macau/" class="textsmall">&#1052;&#1072;&#1082;&#1072;&#1086; (1)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Malaysia/" class="textsmall">&#1052;&#1072;&#1083;&#1072;&#1081;&#1079;&#1080;&#1103; (129)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Nepal/" class="textsmall">&#1053;&#1077;&#1087;&#1072;&#1083; (10)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Philippines/" class="textsmall">&#1060;&#1080;&#1083;&#1080;&#1087;&#1087;&#1080;&#1085;&#1099; (297)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Singapore/" class="textsmall">&#1057;&#1080;&#1085;&#1075;&#1072;&#1087;&#1091;&#1088; (12)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Taiwan/" class="textsmall">&#1058;&#1072;&#1081;&#1074;&#1072;&#1085;&#1100; (14)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Thailand/" class="textsmall">&#1058;&#1072;&#1080;&#1083;&#1072;&#1085;&#1076; (1400)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Vietnam/" class="textsmall">&#1042;&#1100;&#1077;&#1090;&#1085;&#1072;&#1084; (14)</option>
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Cont1/" class="textsmallred">&raquo; &#1040;&#1092;&#1088;&#1080;&#1082;&#1072;</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Cape_Verde/" class="textsmall">&#1050;&#1072;&#1073;&#1086;-&#1042;&#1077;&#1088;&#1076;&#1077; (10)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Kenya/" class="textsmall">&#1050;&#1077;&#1085;&#1080;&#1103; (78)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Lesotho/" class="textsmall">&#1051;&#1077;&#1089;&#1086;&#1090;&#1086; (2)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Madagascar/" class="textsmall">&#1052;&#1072;&#1076;&#1072;&#1075;&#1072;&#1089;&#1082;&#1072;&#1088; (2)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Mauritius/" class="textsmall">&#1052;&#1072;&#1074;&#1088;&#1080;&#1082;&#1080;&#1081; (35)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Morocco/" class="textsmall">&#1052;&#1072;&#1088;&#1086;&#1082;&#1082;&#1086; (89)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Namibia/" class="textsmall">&#1053;&#1072;&#1084;&#1080;&#1073;&#1080;&#1103; (5)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Senegal/" class="textsmall">&#1057;&#1077;&#1085;&#1077;&#1075;&#1072;&#1083; (6)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Seychelles/" class="textsmall">&#1057;&#1077;&#1081;&#1096;&#1077;&#1083;&#1100;&#1089;&#1082;&#1080;&#1077; &#1054;&#1089;&#1090;&#1088;&#1086;&#1074;&#1072; (10)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/South_Africa/" class="textsmall">&#1070;&#1078;&#1085;&#1072;&#1103; &#1040;&#1092;&#1088;&#1080;&#1082;&#1072; (282)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Tanzania/" class="textsmall">&#1058;&#1072;&#1085;&#1079;&#1072;&#1085;&#1080;&#1103; (15)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Tunisia/" class="textsmall">&#1058;&#1091;&#1085;&#1080;&#1089; (51)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Uganda/" class="textsmall">&#1059;&#1075;&#1072;&#1085;&#1076;&#1072; (12)</option>
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Cont2/" class="textsmallred">&raquo; &#1040;&#1079;&#1080;&#1103;</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Bangladesh/" class="textsmall">&#1041;&#1072;&#1085;&#1075;&#1083;&#1072;&#1076;&#1077;&#1096; (5)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/India/" class="textsmall">&#1048;&#1085;&#1076;&#1080;&#1103; (274)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Maldives/" class="textsmall">&#1052;&#1072;&#1083;&#1100;&#1076;&#1080;&#1074;&#1099; (10)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Pakistan/" class="textsmall">&#1055;&#1072;&#1082;&#1080;&#1089;&#1090;&#1072;&#1085; (3)</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Sri_Lanka/" class="textsmall">&#1064;&#1088;&#1080;-&#1051;&#1072;&#1085;&#1082;&#1072; (154)</option>
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Cont9/" class="textsmallred">&raquo; &#1057;&#1077;&#1074;&#1077;&#1088;</option>
                        
                        
                        <option value="http://www.longtermlettings.com/find/rentals/Greenland/" class="textsmall">&#1043;&#1088;&#1077;&#1085;&#1083;&#1072;&#1085;&#1076;&#1080;&#1103; (1)</option>
                        
                      </select>
<div id="pub_loading33">
	<div id="floatingBarsG">
		<div class="blockG" id="rotateG_01">
		</div>
		<div class="blockG" id="rotateG_02">
		</div>
		<div class="blockG" id="rotateG_03">
		</div>
		<div class="blockG" id="rotateG_04">
		</div>
		<div class="blockG" id="rotateG_05">
		</div>
		<div class="blockG" id="rotateG_06">
		</div>
		<div class="blockG" id="rotateG_07">
		</div>
		<div class="blockG" id="rotateG_08">
		</div>
	</div>
</div>
	</div>
</div> 
<div id="advert">
<div class="text-small-white" align="center" style="padding-top:6px; padding-bottom:2px"><b>&#1055;&#1086;&#1076;&#1072;&#1080;&#774;&#1090;&#1077; &#1086;&#1073;&#1098;&#1103;&#1074;&#1083;&#1077;&#1085;&#1080;&#1077; &#1074;&#1089;&#1077;&#1075;&#1086; &#1079;&#1072; 0.99!</b></div>
<div class="textsmall" align="center">
<a href="http://www.holprop.com/agents/" style="text-decoration:none">&#1056;&#1072;&#1079;&#1084;&#1077;&#1097;&#1072;&#1080;&#774;&#1090;&#1077; &#1086;&#1073;&#1098;&#1103;&#1074;&#1083;&#1077;&#1085;&#1080;&#1103; &#1091; &#1085;&#1072;&#1089;!</a>
</div>
<div class="textsmall" style="padding-left:68px; padding-right:7px">
&#1056;&#1072;&#1079;&#1084;&#1077;&#1097;&#1072;&#1080;&#774;&#1090;&#1077; &#1086;&#1073;&#1098;&#1103;&#1074;&#1083;&#1077;&#1085;&#1080;&#1103; &#1091; &#1085;&#1072;&#1089;, &#1087;&#1086;&#1076;&#1085;&#1080;&#1084;&#1080;&#1090;&#1077; &#1074;&#1072;&#1096; &#1073;&#1080;&#1079;&#1085;&#1077;&#1089; &#1080;  &#1087;&#1088;&#1086;&#1076;&#1072;&#1078;&#1080; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080; 
                       &#1085;&#1072; &#1085;&#1086;&#1074;&#1091;&#1102;.</div>

</div>

<div id="news">
<div class="text-small-white" align="center" style="padding:6px"><b>&#1053;&#1086;&#1074;&#1086;&#1089;&#1090;&#1080; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1075;&#1086; &#1080;&#1084;&#1091;&#1097;&#1077;&#1089;&#1090;&#1074;&#1072;</b></div>
	  <div class="search-rss">
        <div align="center" style="height:602px;">
		<script type="text/javascript"><!--
google_ad_client = "ca-pub-1615999687043109";
/* foreign-search-text */
google_ad_slot = "8256922487";
google_ad_width = 160;
google_ad_height = 600;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</div>
	    <br>
	    <H2 class="textsmall">Holprop.ru &#1087;&#1088;&#1077;&#1076;&#1083;&#1072;&#1075;&#1072;&#1077;&#1090; &#1096;&#1080;&#1088;&#1086;&#1082;&#1080;&#1080;&#774; &#1074;&#1099;&#1073;&#1086;&#1088; &#1074;&#1080;&#1083;&#1083; &#1085;&#1072; &#1087;&#1088;&#1086;&#1076;&#1072;&#1078;&#1091; &#1080; &#1089;&#1077;&#1079;&#1086;&#1085;&#1085;&#1086;&#1081; &#1072;&#1088;&#1077;&#1085;&#1076;&#1099;.</H2> &#1087;&#1088;&#1086;&#1089;&#1084;&#1086;&#1090;&#1088;&#1080;&#1090;&#1077; &#1087;&#1088;&#1077;&#1076;&#1083;&#1086;&#1078;&#1077;&#1085;&#1080;&#1103; &#1074; &#1048;&#1089;&#1087;&#1072;&#1085;&#1080;&#1080;, &#1087;&#1088;&#1077;&#1076;&#1083;&#1086;&#1078;&#1077;&#1085;&#1080;&#1103; &#1085;&#1077;&#1076;&#1086;&#1088;&#1086;&#1075;&#1086;&#1080;&#774; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080; &#1079;&#1072; &#1075;&#1088;&#1072;&#1085;&#1080;&#1094;&#1077;&#1080;&#774; &mdash; &#1074; &#1041;&#1086;&#1083;&#1075;&#1072;&#1088;&#1080;&#1080;, &#1076;&#1086;&#1084;&#1072; &#1085;&#1072; &#1087;&#1088;&#1086;&#1076;&#1072;&#1078;&#1091; &#1074; &#1058;&#1091;&#1088;&#1094;&#1080;&#1080;, &#1087;&#1086;&#1082;&#1091;&#1087;&#1072;&#1080;&#774;&#1090;&#1077; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100; &#1074;&#1086; &#1060;&#1083;&#1086;&#1088;&#1080;&#1076;&#1077;, &#1087;&#1088;&#1080;&#1086;&#1073;&#1088;&#1077;&#1090;&#1072;&#1080;&#774;&#1090;&#1077; &#1087;&#1086; &#1074;&#1099;&#1075;&#1086;&#1076;&#1085;&#1099;&#1084; &#1094;&#1077;&#1085;&#1072;&#1084; &#1076;&#1086;&#1084;&#1072; &#1074; &#1050;&#1072;&#1085;&#1072;&#1076;&#1077;, &#1052;&#1077;&#1082;&#1089;&#1080;&#1082;&#1077;, &#1048;&#1090;&#1072;&#1083;&#1080;&#1080;, &#1060;&#1088;&#1072;&#1085;&#1094;&#1080;&#1080;, &#1084;&#1085;&#1086;&#1075;&#1086;&#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1085;&#1099;&#1077; &#1076;&#1086;&#1084;&#1072; &#1085;&#1072; &#1050;&#1072;&#1088;&#1080;&#1073;&#1072;&#1093;, &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100; &#1074; &#1040;&#1074;&#1089;&#1090;&#1088;&#1072;&#1083;&#1080;&#1080; &#1080; &#1076;&#1088;&#1091;&#1075;&#1080;&#1077; &#1087;&#1088;&#1077;&#1076;&#1083;&#1086;&#1078;&#1077;&#1085;&#1080;&#1103; &#1079;&#1072; &#1075;&#1088;&#1072;&#1085;&#1080;&#1094;&#1077;&#1080;&#774;. &#1042;&#1086;&#1089;&#1087;&#1086;&#1083;&#1100;&#1079;&#1091;&#1080;&#774;&#1090;&#1077;&#1089;&#1100; &#1085;&#1072;&#1096;&#1080;&#1084;&#1080; &#1091;&#1076;&#1086;&#1073;&#1085;&#1099;&#1084;&#1080; &#1089;&#1090;&#1088;&#1072;&#1085;&#1080;&#1094;&#1072;&#1084;&#1080; &#1087;&#1086;&#1080;&#1089;&#1082;&#1072;, &#1095;&#1090;&#1086;&#1073;&#1099; &#1073;&#1099;&#1089;&#1090;&#1088;&#1086; &#1085;&#1072;&#1080;&#774;&#1090;&#1080; &#1085;&#1091;&#1078;&#1085;&#1099;&#1080;&#774; &#1074;&#1072;&#1088;&#1080;&#1072;&#1085;&#1090;. &#1041;&#1086;&#1083;&#1100;&#1096;&#1080;&#1085;&#1089;&#1090;&#1074;&#1086; &#1080;&#1079; &#1087;&#1088;&#1080;&#1074;&#1077;&#1076;&#1077;&#1085;&#1085;&#1099;&#1093; &#1074;&#1072;&#1088;&#1080;&#1072;&#1085;&#1090;&#1086;&#1074; &#1087;&#1088;&#1086;&#1076;&#1072;&#1102;&#1090;&#1089;&#1103; &#1080;&#1083;&#1080; &#1089;&#1076;&#1072;&#1102;&#1090;&#1089;&#1103; &#1074; &#1072;&#1088;&#1077;&#1085;&#1076;&#1091; &#1085;&#1077;&#1087;&#1086;&#1089;&#1088;&#1077;&#1076;&#1089;&#1090;&#1074;&#1077;&#1085;&#1085;&#1086; &#1080;&#1093; &#1074;&#1083;&#1072;&#1076;&#1077;&#1083;&#1100;&#1094;&#1072;&#1084;&#1080;.&lt;br&gt; 
  &#1045;&#1089;&#1083;&#1080; &#1074;&#1099; &#1093;&#1086;&#1090;&#1080;&#1090;&#1077; &#1072;&#1088;&#1077;&#1085;&#1076;&#1086;&#1074;&#1072;&#1090;&#1100; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100; &#1076;&#1083;&#1103; &#1086;&#1090;&#1076;&#1099;&#1093;&#1072;, &#1091; &#1085;&#1072;&#1089; &#1077;&#1089;&#1090;&#1100; &#1096;&#1080;&#1088;&#1086;&#1082;&#1080;&#1080;&#774; &#1074;&#1099;&#1073;&#1086;&#1088; &#1076;&#1086;&#1084;&#1086;&#1074; &#1079;&#1072; &#1075;&#1088;&#1072;&#1085;&#1080;&#1094;&#1077;&#1080;&#774; &#1085;&#1072;&#1087;&#1088;&#1103;&#1084;&#1091;&#1102; &#1086;&#1090; &#1074;&#1083;&#1072;&#1076;&#1077;&#1083;&#1100;&#1094;&#1077;&#1074;.
                        <br>
                             <a href="holiday_rentals~scr~Spain.htm">&#1048;&#1089;&#1087;&#1072;&#1085;&#1080;&#1103;</a>, <a href="holiday_rentals~scr~France.htm">&#1060;&#1088;&#1072;&#1085;&#1094;&#1080;&#1103;</a>, <a href="holiday_rentals~scr~Portugal.htm">&#1055;&#1086;&#1088;&#1090;&#1091;&#1075;&#1072;&#1083;&#1080;&#1103;</a>, <a href="holiday_rentals~scr~Italy.htm">&#1048;&#1090;&#1072;&#1083;&#1080;&#1103;</a>, <a href="holiday_rentals~scr~Cyprus.htm">&#1050;&#1080;&#1087;&#1088;</a>, <a href="holiday_rentals~scr~USA~srg~Florida.htm">&#1060;&#1083;&#1086;&#1088;&#1080;&#1076;&#1072;</a>, <a href="holiday_rentals~scr~USA.htm">&#1040;&#1084;&#1077;&#1088;&#1080;&#1082;&#1072;&#1085;&#1089;&#1082;&#1080;&#1077;</a>, <a href="holiday_rentals~scr~Canada.htm">&#1050;&#1072;&#1085;&#1072;&#1076;&#1072;</a>, <a href="holiday_rentals~scr~Mexico.htm">&#1052;&#1077;&#1082;&#1089;&#1080;&#1082;&#1072;</a> <a href="property_sales~scr~Spain~srg~Andalucia~sct~Costa+del+Sol.htm">Costa del Sol</a> | <a href="property_sales~scr~Spain~srg~Valencia~sct~Alicante-Costa+Blanca.htm">Costa Blanca</a> | <a href="property_sales~scr~Spain~srg~Murcia~sct~Costa+Calida.htm">Costa Calida</a> | <a href="property_sales~scr~Spain~srg~Andalucia~sct~Costa+De+La+Luz.htm">Costa De La Luz</a> | <a href="property_sales~scr~Spain~srg~Andalucia~sct~Costa+de+Almeria.htm">Costa de Almeria</a><br>
                              <br>
                              <br>
	<a href="property_sales~scr~Spain~srg~Valencia~sltcity~Javea-Xabia.htm">&#1055;&#1088;&#1080;&#1086;&#1073;&#1088;&#1077;&#1089;&#1090;&#1080; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100; Javea</a> | <a href="holiday_rentals~scr~Spain~srg~Valencia~sltcity~Javea-Xabia.htm">Javea &#1040;&#1088;&#1077;&#1085;&#1076;&#1072; &#1085;&#1072; &#1082;&#1086;&#1088;&#1086;&#1090;&#1082;&#1080;&#1081; &#1089;&#1088;&#1086;&#1082;</a> | <a href="property_sales~scr~Spain~srg~Valencia~sltcity~Moraira.htm">&#1055;&#1088;&#1080;&#1086;&#1073;&#1088;&#1077;&#1089;&#1090;&#1080; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100; Moraira</a> | <a href="property_sales~scr~Spain~srg~Valencia~sltcity~Denia.htm">&#1055;&#1088;&#1080;&#1086;&#1073;&#1088;&#1077;&#1089;&#1090;&#1080; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100; Denia</a> | <a href="property_sales~scr~Spain~srg~Andalucia~sltcity~Marbella.htm">&#1055;&#1088;&#1080;&#1086;&#1073;&#1088;&#1077;&#1089;&#1090;&#1080; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100; Marbella</a> | <a href="property_sales~scr~Spain~srg~Andalucia~sltcity~Malaga.htm">&#1055;&#1088;&#1080;&#1086;&#1073;&#1088;&#1077;&#1089;&#1090;&#1080; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100; Malaga</a><br>
	<br>
	<a href="http://www.holprop.com/property/sale/Spain/Valencia/Javea-Xabia/">Javea real estate</a> | <a href="http://www.search-villas.com/holiday/rentals/Spain/Valencia/Javea-Xabia/">villa rentals Javea</a> | <a href="http://www.holprop.com/property/sale/Spain/Valencia/Moraira/">Moraira real estate</a> | <a href="http://www.holprop.com/property/sale/Spain/Valencia/Denia/">Denia real estate</a> | <a href="http://www.holprop.com/property/sale/Spain/Andalucia/Marbella/">Marbella real estate</a> | <a href="http://www.holprop.com/property/sale/Spain/Andalucia/Malaga/">Malaga real estate</a> </div>
</div>
<div id="invest">
<div class="text-small-white" align="center" style="padding:6px"><b>&#1048;&#1085;&#1074;&#1077;&#1089;&#1090;&#1080;&#1094;&#1080;&#1086;&#1085;&#1085;&#1099;&#1077; &#1074;&#1086;&#1079;&#1084;&#1086;&#1078;&#1085;&#1086;&#1089;&#1090;&#1080;</b></div>
<div class="invest-text"><a href="http://www.holprop.com/investments/">
&#1080;&#1085;&#1074;&#1077;&#1089;&#1090;&#1080;&#1094;&#1080;&#1086;&#1085;&#1085;&#1099;&#1077; &#1074;&#1086;&#1079;&#1084;&#1086;&#1078;&#1085;&#1086;&#1089;&#1090;&#1080;</a> &#1089;&#1086; &#1074;&#1089;&#1077;&#1075;&#1086; &#1084;&#1080;&#1088;&#1072;.

<br>



<br><img src="images/fl/St._Kitts-Nevis.gif" alt="St._Kitts-Nevis"> <a href="http://www.holprop.com/investments/?id=195">&#1055;&#1086;&#1090;&#1088;&#1103;&#1089;&#1072;&#1102;&#1097;&#1080;&#1077; &#1050;&#1072;&#1088;&#1080;&#1073;&#1089;&#1082;&#1086;&#1075;&#1086; &#1073;&#1072;&#1089;&#1089;&#1077;&#1081;&#1085;&#1072; &#1042;&#1099;&#1073;&#1086;&#1088; | &#1054;&#1090; 107K GBP</a> (2/5/2015)<br>




<br><img src="images/fl/England.gif" alt="England"> <a href="http://www.holprop.com/investments/?id=194">&#1042;&#1074;&#1077;&#1076;&#1077;&#1085;&#1080;&#1077; Clifton Moor &#1076;&#1086;&#1084;&#1072;&#1096;&#1085;&#1077;&#1075;&#1086; &#1091;&#1093;&#1086;&#1076;&#1072; | 10% &#1074;&#1086;&#1079;&#1074;&#1088;&#1072;&#1097;&#1072;&#1077;&#1090;&#1089;&#1103; &#1074; &#1090;&#1077;&#1095;&#1077;&#1085;&#1080;&#1077; 10 &#1083;&#1077;&#1090;</a> (2/3/2015)<br>




<br><img src="images/fl/England.gif" alt="England"> <a href="http://www.holprop.com/investments/?id=193">&#1053;&#1086;&#1074;&#1099;&#1081; &#1088;&#1077;&#1083;&#1080;&#1079; | &#1055;&#1086;&#1090;&#1088;&#1103;&#1089;&#1072;&#1102;&#1097;&#1080;&#1077; &#1072;&#1087;&#1072;&#1088;&#1090;&#1072;&#1084;&#1077;&#1085;&#1090;&#1099; &#1089; 2 &#1089;&#1087;&#1072;&#1083;&#1100;&#1085;&#1103;&#1084;&#1080; &#1086;&#1090; &pound; 87360 | &#1076;&#1086; &pound; 8040 &#1042;&#1086;&#1079;&#1074;&#1088;&#1072;&#1097;&#1072;&#1077;&#1090;</a> (2/2/2015)<br>




<br><img src="images/fl/England.gif" alt="England"> <a href="http://www.holprop.com/investments/?id=192">&#1055;&#1088;&#1077;&#1076;&#1089;&#1090;&#1072;&#1074;&#1083;&#1103;&#1077;&#1084; &#1064;&#1077;&#1085;&#1082;&#1083;&#1080; &#1086;&#1090;&#1077;&#1083;&#1100; | &#1076;&#1086; 10,5% &#1042;&#1086;&#1079;&#1074;&#1088;&#1072;&#1097;&#1072;&#1077;&#1090; &#1074; &#1094;&#1077;&#1085;&#1090;&#1088;&#1077; &#1051;&#1080;&#1074;&#1077;&#1088;&#1087;&#1091;&#1083;&#1103;</a> (1/29/2015)<br>




<br><img src="images/fl/England.gif" alt="England"> <a href="http://www.holprop.com/investments/?id=191">&#1060;&#1072;&#1085;&#1090;&#1072;&#1089;&#1090;&#1080;&#1095;&#1077;&#1089;&#1082;&#1072;&#1103; &#1042;&#1077;&#1083;&#1080;&#1082;&#1086;&#1073;&#1088;&#1080;&#1090;&#1072;&#1085;&#1080;&#1103; &#1050;&#1091;&#1087;&#1080;&#1090;&#1100; &#1076;&#1086; &#1075;&#1086;&#1074;&#1086;&#1088;&#1103; &#1074;&#1086;&#1079;&#1084;&#1086;&#1078;&#1085;&#1086;&#1089;&#1090;&#1077;&#1081; | &#1054;&#1090; 50K GBP</a> (1/15/2015)<br>




<br><img src="images/fl/England.gif" alt="England"> <a href="http://www.holprop.com/investments/?id=190">&#1055;&#1086;&#1083;&#1085;&#1086;&#1089;&#1090;&#1100;&#1102; &#1087;&#1086;&#1089;&#1090;&#1088;&#1086;&#1077;&#1085; &#1080; &#1086;&#1087;&#1077;&#1088;&#1072;&#1090;&#1080;&#1074;&#1085;&#1086;&#1077; &#1042;&#1086;&#1079;&#1084;&#1086;&#1078;&#1085;&#1086;&#1089;&#1090;&#1100; &#1042;&#1077;&#1083;&#1080;&#1082;&#1086;&#1073;&#1088;&#1080;&#1090;&#1072;&#1085;&#1080;&#1103; &#1059;&#1093;&#1086;&#1076;</a> (1/14/2015)<br>




<br><img src="images/fl/England.gif" alt="England"> <a href="http://www.holprop.com/investments/?id=189">&#1043;&#1072;&#1088;&#1072;&#1085;&#1090;&#1080;&#1088;&#1086;&#1074;&#1072;&#1085;&#1085;&#1099;&#1081; &#1095;&#1080;&#1089;&#1090;&#1099;&#1081; &#1076;&#1086;&#1093;&#1086;&#1076; &#1074; &#1088;&#1072;&#1079;&#1084;&#1077;&#1088;&#1077; 7% &#1074; &#1090;&#1077;&#1095;&#1077;&#1085;&#1080;&#1077; &#1087;&#1077;&#1088;&#1074;&#1099;&#1093; 2 &#1083;&#1077;&#1090; - &#1041;&#1077;&#1079;&#1086;&#1087;&#1072;&#1089;&#1085;&#1099;&#1081; &#1044;&#1086; 20K &#1074; &#1082;&#1072;&#1087;&#1080;&#1090;&#1072;&#1083;&#1077; &#1085;&#1072; 1 &#1076;&#1077;&#1085;&#1100;</a> (1/13/2015)<br>




<br><img src="images/fl/England.gif" alt="England"> <a href="http://www.holprop.com/investments/?id=188">10% NET &#1074; &#1090;&#1077;&#1095;&#1077;&#1085;&#1080;&#1077; 10 &#1083;&#1077;&#1090; | &#1042;&#1077;&#1083;&#1080;&#1082;&#1086;&#1073;&#1088;&#1080;&#1090;&#1072;&#1085;&#1080;&#1103; &#1089;&#1090;&#1091;&#1076;&#1077;&#1085;&#1090; &#1080;&#1085;&#1074;&#1077;&#1089;&#1090;&#1080;&#1094;&#1080;&#1080; &#1074; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</a> (1/8/2015)<br>




<br><img src="images/fl/England.gif" alt="England"> <a href="http://www.holprop.com/investments/?id=187">6% &#1087;&#1088;&#1080;&#1073;&#1099;&#1083;&#1100; &#1086;&#1090; &#1072;&#1088;&#1077;&#1085;&#1076;&#1099; &#1074;&#1086;&#1079;&#1074;&#1088;&#1072;&#1097;&#1072;&#1077;&#1090;&#1089;&#1103; &#1091;&#1074;&#1077;&#1088;&#1077;&#1085;&#1099; &#1074; &#1090;&#1077;&#1095;&#1077;&#1085;&#1080;&#1077; &#1087;&#1077;&#1088;&#1074;&#1086;&#1075;&#1086; &#1075;&#1086;&#1076;&#1072;</a> (1/5/2015)<br>




<br><img src="images/fl/USA.gif" alt="USA"> <a href="http://www.holprop.com/investments/?id=186">&#1060;&#1083;&#1086;&#1088;&#1080;&#1076;&#1072; &#1080;&#1085;&#1074;&#1077;&#1089;&#1090;&#1080;&#1094;&#1080;&#1080; &#1074; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100; | 6% &#1075;&#1086;&#1076;&#1086;&#1074;&#1099;&#1093; NET &#1075;&#1072;&#1088;&#1072;&#1085;&#1090;&#1080;&#1088;&#1091;&#1077;&#1090;&#1089;&#1103; &#1076;&#1086;&#1093;&#1086;&#1076;&#1085;&#1086;&#1089;&#1090;&#1100; &#1072;&#1088;&#1077;&#1085;&#1076;&#1099; &#1085;&#1072; 5 &#1083;&#1077;&#1090;</a> (12/16/2014)<br>


  
</div>	  
</div>
</div>

<div class="floatleft" style="width:720px">
<div style="margin:10px" class="textsmall" align="center"><b>&#1055;&#1086;&#1080;&#1089;&#1082;</b></div>
                     <div align="center" class="text-big"><a href="property_sales.htm">&#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080; <span class="text-small-gray">(75 675)</span></a> | <a href="holiday_rentals.htm">&#1040;&#1088;&#1077;&#1085;&#1076;&#1072; &#1085;&#1072; &#1074;&#1099;&#1093;&#1086;&#1076;&#1085;&#1099;&#1077; <span class="text-small-gray">(156 826)</span></a> | <a href="http://www.longtermlettings.com/">&#1076;&#1086;&#1083;&#1075;&#1086;&#1089;&#1088;&#1086;&#1095;&#1085;&#1072;&#1103; &#1072;&#1088;&#1077;&#1085;&#1076;&#1072; <span class="text-small-gray">(46 413)</span></a></div>
                      <div align="center" style="margin:4px" class="textsmall">www.holprop.ru - &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;!</div>
<div class="bgmainblank">
			<div id="slideshow">
			<div class="bgmain">
<div>
			
	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://kyero.cloudimage.io/s/crop/400x300/https://production.kyero.s3.amazonaws.com/2583/2583241/19057013_original.jpg?a1c696d794eb2301a5aa95f490519a8b29491e2f'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~ES7775900.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1048;&#1089;&#1087;&#1072;&#1085;&#1080;&#1103;, Andalucia, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 6"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~ES7775900.htm" title="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1048;&#1089;&#1087;&#1072;&#1085;&#1080;&#1103;, Andalucia, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 6"><b>&#1048;&#1089;&#1087;&#1072;&#1085;&#1080;&#1103;</b></a> <br>
              &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;<br>
            Andalucia<br>
              <a href="property_sales~scr~Spain~srg~Andalucia~sltcity~Marbella.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Marbella, &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 6"><span class="textsmall">Marbella</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 6<br>
            <b>&euro; 925 000</b>	
</div>
</div>	
</div>

	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.co.uk/cache/img-xml/snoeoobfivpvfow_7.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~ES12992569.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1099; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1048;&#1089;&#1087;&#1072;&#1085;&#1080;&#1103;, Andalucia, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 3"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~ES12992569.htm" title="&#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1099; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1048;&#1089;&#1087;&#1072;&#1085;&#1080;&#1103;, Andalucia, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 3"><b>&#1048;&#1089;&#1087;&#1072;&#1085;&#1080;&#1103;</b></a> <br>
              &#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1099;<br>
            Andalucia<br>
              <a href="property_sales~scr~Spain~srg~Andalucia~sltcity~Puerto+Banus.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Puerto Banus, &#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1099;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 3"><span class="textsmall">Puerto Banus</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 3<br>
            <b>&euro; 5 000 000</b>	
</div>
</div>	
</div>

	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.com/s/CH7674469/images/property/image01_thumb.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~CH7674469.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1099; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1064;&#1074;&#1077;&#1081;&#1094;&#1072;&#1088;&#1080;&#1103;, Wallis, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 0"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~CH7674469.htm" title="&#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1099; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1064;&#1074;&#1077;&#1081;&#1094;&#1072;&#1088;&#1080;&#1103;, Wallis, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 0"><b>&#1064;&#1074;&#1077;&#1081;&#1094;&#1072;&#1088;&#1080;&#1103;</b></a> <br>
              &#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1099;<br>
            Wallis<br>
              <a href="property_sales~scr~Switzerland~srg~Wallis~sltcity~Anzere.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Anzere, &#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1099;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 0"><span class="textsmall">Anzere</span></a><br>
              &#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1099;<br>
              <b>&euro; 85 000</b>	
</div>
</div>	
</div>

	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.co.uk/cache/img-tmc2/img_main17659.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~FR12954535.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1060;&#1088;&#1072;&#1085;&#1094;&#1080;&#1103;, Alpes-Cote d`Azur, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 4"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~FR12954535.htm" title="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1060;&#1088;&#1072;&#1085;&#1094;&#1080;&#1103;, Alpes-Cote d`Azur, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 4"><b>&#1060;&#1088;&#1072;&#1085;&#1094;&#1080;&#1103;</b></a> <br>
              &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;<br>
            Alpes-Cote d'Azur<br>
              <a href="property_sales~scr~France~srg~Alpes-Cote+d`Azur~sltcity~Alpes-Maritimes.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Alpes-Maritimes, &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 4"><span class="textsmall">Alpes-Maritimes</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 4<br>
            <b>&euro; 1 280 000</b>	
</div>
</div>	
</div>

</div>
				<div>

			
	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.co.uk/cache/img-xml3/thumb_5832.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~TH12960453.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1058;&#1072;&#1080;&#1083;&#1072;&#1085;&#1076;, Phuket, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 2"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~TH12960453.htm" title="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1058;&#1072;&#1080;&#1083;&#1072;&#1085;&#1076;, Phuket, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 2"><b>&#1058;&#1072;&#1080;&#1083;&#1072;&#1085;&#1076;</b></a> <br>
              &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;<br>
            Phuket<br>
              <a href="property_sales~scr~Thailand~srg~Phuket~sltcity~Nai+Harn.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Nai Harn, &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 2"><span class="textsmall">Nai Harn</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 2<br>
            <b>&euro; 230 310</b>	
</div>
</div>	
</div>

	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.co.uk/cache/img-xml3/thumb_6062.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~TH7948981.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1058;&#1072;&#1080;&#1083;&#1072;&#1085;&#1076;, Phuket, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~TH7948981.htm" title="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1058;&#1072;&#1080;&#1083;&#1072;&#1085;&#1076;, Phuket, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5"><b>&#1058;&#1072;&#1080;&#1083;&#1072;&#1085;&#1076;</b></a> <br>
              &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;<br>
            Phuket<br>
              <a href="property_sales~scr~Thailand~srg~Phuket~sltcity~Nai+thon.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Nai thon, &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5"><span class="textsmall">Nai thon</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5<br>
            <b>&euro; 7 833 213</b>	
</div>
</div>	
</div>

	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.co.uk/cache/img-tmc2/img_main18001.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~BB12957418.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1041;&#1072;&#1088;&#1073;&#1072;&#1076;&#1086;&#1089;, St. James, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 4"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~BB12957418.htm" title="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1041;&#1072;&#1088;&#1073;&#1072;&#1076;&#1086;&#1089;, St. James, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 4"><b>&#1041;&#1072;&#1088;&#1073;&#1072;&#1076;&#1086;&#1089;</b></a> <br>
              &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;<br>
            St. James<br>
              <a href="property_sales~scr~Barbados~srg~St.+James~sltcity~Westmoreland.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Westmoreland, &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 4"><span class="textsmall">Westmoreland</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 4<br>
            <b>&euro; 3 632 113</b>	
</div>
</div>	
</div>

	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.com/s/LC148023/images/property/image01_thumb.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~LC148023.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1057;&#1077;&#1085;-&#1052;&#1072;&#1088;&#1090;&#1077;&#1085;, Caribbean, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 3"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~LC148023.htm" title="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1057;&#1077;&#1085;-&#1052;&#1072;&#1088;&#1090;&#1077;&#1085;, Caribbean, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 3"><b>&#1057;&#1077;&#1085;-&#1052;&#1072;&#1088;&#1090;&#1077;&#1085;</b></a> <br>
              &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;<br>
            Caribbean<br>
              <a href="property_sales~scr~St.+Maarten~srg~Caribbean~sltcity~Netherlands+Antilles.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Netherlands Antilles, &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 3"><span class="textsmall">Netherlands Antilles</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 3<br>
            <b>$ 1 900 000</b>	
</div>
</div>	
</div>

</div>
</div>
<div class="bgmain">
<div>
			
	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.co.uk/cache/img-xml/oaxljfpraoyxwue_7.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~ES12992546.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1048;&#1089;&#1087;&#1072;&#1085;&#1080;&#1103;, Andalucia, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~ES12992546.htm" title="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1048;&#1089;&#1087;&#1072;&#1085;&#1080;&#1103;, Andalucia, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5"><b>&#1048;&#1089;&#1087;&#1072;&#1085;&#1080;&#1103;</b></a> <br>
              &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;<br>
            Andalucia<br>
              <a href="property_sales~scr~Spain~srg~Andalucia~sltcity~Nueva+Andalucia.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Nueva Andalucia, &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5"><span class="textsmall">Nueva Andalucia</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5<br>
            <b>&euro; 6 200 000</b>	
</div>
</div>	
</div>

	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.co.uk/cache/img-tmc2/img_main17730.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~FR12954552.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1060;&#1088;&#1072;&#1085;&#1094;&#1080;&#1103;, Alpes-Cote d`Azur, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 4"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~FR12954552.htm" title="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1060;&#1088;&#1072;&#1085;&#1094;&#1080;&#1103;, Alpes-Cote d`Azur, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 4"><b>&#1060;&#1088;&#1072;&#1085;&#1094;&#1080;&#1103;</b></a> <br>
              &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;<br>
            Alpes-Cote d'Azur<br>
              <a href="property_sales~scr~France~srg~Alpes-Cote+d`Azur~sltcity~Alpes-Maritimes.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Alpes-Maritimes, &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 4"><span class="textsmall">Alpes-Maritimes</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 4<br>
            <b>&euro; 1 495 000</b>	
</div>
</div>	
</div>

	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.co.uk/cache/img-tmc2/img_main18269.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~FR12954684.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1060;&#1088;&#1072;&#1085;&#1094;&#1080;&#1103;, Alpes-Cote d`Azur, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~FR12954684.htm" title="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1060;&#1088;&#1072;&#1085;&#1094;&#1080;&#1103;, Alpes-Cote d`Azur, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5"><b>&#1060;&#1088;&#1072;&#1085;&#1094;&#1080;&#1103;</b></a> <br>
              &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;<br>
            Alpes-Cote d'Azur<br>
              <a href="property_sales~scr~France~srg~Alpes-Cote+d`Azur~sltcity~Var.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Var, &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5"><span class="textsmall">Var</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5<br>
            <b>&euro; 4 900 000</b>	
</div>
</div>	
</div>

	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.co.uk/cache/img-xml/124526_3.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~ES11604632.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1048;&#1089;&#1087;&#1072;&#1085;&#1080;&#1103;, Valencia, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 3"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~ES11604632.htm" title="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1048;&#1089;&#1087;&#1072;&#1085;&#1080;&#1103;, Valencia, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 3"><b>&#1048;&#1089;&#1087;&#1072;&#1085;&#1080;&#1103;</b></a> <br>
              &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;<br>
            Valencia<br>
              <a href="property_sales~scr~Spain~srg~Valencia~sltcity~Benissa.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Benissa, &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 3"><span class="textsmall">Benissa</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 3<br>
            <b>&euro; 395 000</b>	
</div>
</div>	
</div>

</div>
				<div>

			
	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.co.uk/cache/img-xml3/thumb_6271.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~TH11409800.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1058;&#1072;&#1080;&#1083;&#1072;&#1085;&#1076;, Phuket, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 1"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~TH11409800.htm" title="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1058;&#1072;&#1080;&#1083;&#1072;&#1085;&#1076;, Phuket, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 1"><b>&#1058;&#1072;&#1080;&#1083;&#1072;&#1085;&#1076;</b></a> <br>
              &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;<br>
            Phuket<br>
              <a href="property_sales~scr~Thailand~srg~Phuket~sltcity~Layan.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Layan, &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 1"><span class="textsmall">Layan</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 1<br>
            <b>&euro; 160 681</b>	
</div>
</div>	
</div>

	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.co.uk/cache/img-tmc2/img_main17431.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~BB12957381.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1099; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1041;&#1072;&#1088;&#1073;&#1072;&#1076;&#1086;&#1089;, St. James, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 1"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~BB12957381.htm" title="&#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1099; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1041;&#1072;&#1088;&#1073;&#1072;&#1076;&#1086;&#1089;, St. James, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 1"><b>&#1041;&#1072;&#1088;&#1073;&#1072;&#1076;&#1086;&#1089;</b></a> <br>
              &#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1099;<br>
            St. James<br>
              <a href="property_sales~scr~Barbados~srg~St.+James~sltcity~Holetown.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Holetown, &#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1099;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 1"><span class="textsmall">Holetown</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 1<br>
            <b>&euro; 544 846</b>	
</div>
</div>	
</div>

	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.co.uk/cache/img-tmc2/img_main17729.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~BB12957396.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1041;&#1072;&#1088;&#1073;&#1072;&#1076;&#1086;&#1089;, St. James, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~BB12957396.htm" title="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1041;&#1072;&#1088;&#1073;&#1072;&#1076;&#1086;&#1089;, St. James, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5"><b>&#1041;&#1072;&#1088;&#1073;&#1072;&#1076;&#1086;&#1089;</b></a> <br>
              &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;<br>
            St. James<br>
              <a href="property_sales~scr~Barbados~srg~St.+James~sltcity~Caribbean.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Caribbean, &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5"><span class="textsmall">Caribbean</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5<br>
            <b>&euro; 2 624 726</b>	
</div>
</div>	
</div>

	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.co.uk/cache/img-xml3/thumb_6060.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~TH7948992.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1058;&#1072;&#1080;&#1083;&#1072;&#1085;&#1076;, Phuket, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 4"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~TH7948992.htm" title="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1058;&#1072;&#1080;&#1083;&#1072;&#1085;&#1076;, Phuket, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 4"><b>&#1058;&#1072;&#1080;&#1083;&#1072;&#1085;&#1076;</b></a> <br>
              &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;<br>
            Phuket<br>
              <a href="property_sales~scr~Thailand~srg~Phuket~sltcity~Kamala.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Kamala, &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 4"><span class="textsmall">Kamala</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 4<br>
            <b>&euro; 709 676</b>	
</div>
</div>	
</div>

</div>
</div>
<div class="bgmain">
<div>
			
	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.co.uk/cache/img-tmc2/img_main17738.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~FR12954556.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1060;&#1088;&#1072;&#1085;&#1094;&#1080;&#1103;, Alpes-Cote d`Azur, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 4"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~FR12954556.htm" title="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1060;&#1088;&#1072;&#1085;&#1094;&#1080;&#1103;, Alpes-Cote d`Azur, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 4"><b>&#1060;&#1088;&#1072;&#1085;&#1094;&#1080;&#1103;</b></a> <br>
              &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;<br>
            Alpes-Cote d'Azur<br>
              <a href="property_sales~scr~France~srg~Alpes-Cote+d`Azur~sltcity~Alpes-Maritimes.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Alpes-Maritimes, &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 4"><span class="textsmall">Alpes-Maritimes</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 4<br>
            <b>&euro; 9 500 000</b>	
</div>
</div>	
</div>

	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.co.uk/cache/img-xml2/10351400584378156005c5baf40ff51a327f1c34f2975b_3.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~PT11425527.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1055;&#1086;&#1088;&#1090;&#1091;&#1075;&#1072;&#1083;&#1080;&#1103;, Porto-North Portugal, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 6"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~PT11425527.htm" title="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1055;&#1086;&#1088;&#1090;&#1091;&#1075;&#1072;&#1083;&#1080;&#1103;, Porto-North Portugal, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 6"><b>&#1055;&#1086;&#1088;&#1090;&#1091;&#1075;&#1072;&#1083;&#1080;&#1103;</b></a> <br>
              &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;<br>
            Porto-North Portugal<br>
              <a href="property_sales~scr~Portugal~srg~Porto-North+Portugal~sltcity~Vila+Nova+De+Cerveira.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Vila Nova De Cerveira, &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 6"><span class="textsmall">Vila Nova De Cerveira</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 6<br>
            <b>&euro; 201 000</b>	
</div>
</div>	
</div>

	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.co.uk/cache/img-tmc2/img_main17783.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~FR12954574.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1060;&#1088;&#1072;&#1085;&#1094;&#1080;&#1103;, Alpes-Cote d`Azur, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 6"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~FR12954574.htm" title="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1060;&#1088;&#1072;&#1085;&#1094;&#1080;&#1103;, Alpes-Cote d`Azur, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 6"><b>&#1060;&#1088;&#1072;&#1085;&#1094;&#1080;&#1103;</b></a> <br>
              &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;<br>
            Alpes-Cote d'Azur<br>
              <a href="property_sales~scr~France~srg~Alpes-Cote+d`Azur~sltcity~Alpes-Maritimes.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Alpes-Maritimes, &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 6"><span class="textsmall">Alpes-Maritimes</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 6<br>
            <b>&euro; 8 450 000</b>	
</div>
</div>	
</div>

	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.co.uk/cache/img-tmc2/img_main17709.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~FR12954548.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1060;&#1088;&#1072;&#1085;&#1094;&#1080;&#1103;, Alpes-Cote d`Azur, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~FR12954548.htm" title="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1060;&#1088;&#1072;&#1085;&#1094;&#1080;&#1103;, Alpes-Cote d`Azur, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5"><b>&#1060;&#1088;&#1072;&#1085;&#1094;&#1080;&#1103;</b></a> <br>
              &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;<br>
            Alpes-Cote d'Azur<br>
              <a href="property_sales~scr~France~srg~Alpes-Cote+d`Azur~sltcity~Vaucluse.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Vaucluse, &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5"><span class="textsmall">Vaucluse</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5<br>
            <b>&euro; 3 350 000</b>	
</div>
</div>	
</div>

</div>
				<div>

			
	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.co.uk/cache/img-tmc2/img_main20709.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~BB12957496.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1041;&#1072;&#1088;&#1073;&#1072;&#1076;&#1086;&#1089;, St. James, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 3"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~BB12957496.htm" title="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1041;&#1072;&#1088;&#1073;&#1072;&#1076;&#1086;&#1089;, St. James, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 3"><b>&#1041;&#1072;&#1088;&#1073;&#1072;&#1076;&#1086;&#1089;</b></a> <br>
              &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;<br>
            St. James<br>
              <a href="property_sales~scr~Barbados~srg~St.+James~sltcity~Sandy+Lane.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Sandy Lane, &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 3"><span class="textsmall">Sandy Lane</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 3<br>
            <b>&euro; 2 569 296</b>	
</div>
</div>	
</div>

	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.co.uk/cache/img-tmc2/img_main19586.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~TH12776975.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1099; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1058;&#1072;&#1080;&#1083;&#1072;&#1085;&#1076;, Phuket, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 2"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~TH12776975.htm" title="&#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1099; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1058;&#1072;&#1080;&#1083;&#1072;&#1085;&#1076;, Phuket, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 2"><b>&#1058;&#1072;&#1080;&#1083;&#1072;&#1085;&#1076;</b></a> <br>
              &#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1099;<br>
            Phuket<br>
              <a href="property_sales~scr~Thailand~srg~Phuket~sltcity~Kathu.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Kathu, &#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1099;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 2"><span class="textsmall">Kathu</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 2<br>
            <b>&euro; 197 178</b>	
</div>
</div>	
</div>

	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.co.uk/cache/img-tmc2/img_main18169.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~BB12957445.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1041;&#1072;&#1088;&#1073;&#1072;&#1076;&#1086;&#1089;, St. James, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~BB12957445.htm" title="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1041;&#1072;&#1088;&#1073;&#1072;&#1076;&#1086;&#1089;, St. James, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5"><b>&#1041;&#1072;&#1088;&#1073;&#1072;&#1076;&#1086;&#1089;</b></a> <br>
              &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;<br>
            St. James<br>
              <a href="property_sales~scr~Barbados~srg~St.+James~sltcity~Westmoreland.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Westmoreland, &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5"><span class="textsmall">Westmoreland</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5<br>
            <b>&euro; 2 826 396</b>	
</div>
</div>	
</div>

	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.co.uk/cache/img-xml3/thumb_6064.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~TH7948969.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1085;&#1099;&#1077; &#1076;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1058;&#1072;&#1080;&#1083;&#1072;&#1085;&#1076;, Phuket, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 3"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~TH7948969.htm" title="&#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1085;&#1099;&#1077; &#1076;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1058;&#1072;&#1080;&#1083;&#1072;&#1085;&#1076;, Phuket, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 3"><b>&#1058;&#1072;&#1080;&#1083;&#1072;&#1085;&#1076;</b></a> <br>
              &#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1085;&#1099;&#1077; &#1076;&#1086;&#1084;&#1072;<br>
            Phuket<br>
              <a href="property_sales~scr~Thailand~srg~Phuket~sltcity~Cape+Yamu.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Cape Yamu, &#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1085;&#1099;&#1077; &#1076;&#1086;&#1084;&#1072;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 3"><span class="textsmall">Cape Yamu</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 3<br>
            <b>&euro; 318 685</b>	
</div>
</div>	
</div>

</div>
</div>
<div class="bgmain">

<div>
			
	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.co.uk/cache/img-xml2/281364173453cc72fce98d1b0ae5247b0407c8c1dbe2_3.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~PT7782987.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1090;&#1072;&#1091;&#1085;-&#1093;&#1072;&#1091;&#1089;&#1099; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1055;&#1086;&#1088;&#1090;&#1091;&#1075;&#1072;&#1083;&#1080;&#1103;, Algarve, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 3"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~PT7782987.htm" title="&#1090;&#1072;&#1091;&#1085;-&#1093;&#1072;&#1091;&#1089;&#1099; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1055;&#1086;&#1088;&#1090;&#1091;&#1075;&#1072;&#1083;&#1080;&#1103;, Algarve, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 3"><b>&#1055;&#1086;&#1088;&#1090;&#1091;&#1075;&#1072;&#1083;&#1080;&#1103;</b></a> <br>
              &#1090;&#1072;&#1091;&#1085;-&#1093;&#1072;&#1091;&#1089;&#1099;<br>
            Algarve<br>
              <a href="property_sales~scr~Portugal~srg~Algarve~sltcity~Burgau.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Burgau, &#1090;&#1072;&#1091;&#1085;-&#1093;&#1072;&#1091;&#1089;&#1099;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 3"><span class="textsmall">Burgau</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 3<br>
            <b>&euro; 259 950</b>	
</div>
</div>	
</div>

	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.co.uk/cache/img-xml3/51385632.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~ES12909990.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1048;&#1089;&#1087;&#1072;&#1085;&#1080;&#1103;, Valencia, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 3"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~ES12909990.htm" title="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1048;&#1089;&#1087;&#1072;&#1085;&#1080;&#1103;, Valencia, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 3"><b>&#1048;&#1089;&#1087;&#1072;&#1085;&#1080;&#1103;</b></a> <br>
              &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;<br>
            Valencia<br>
              <a href="property_sales~scr~Spain~srg~Valencia~sltcity~Gata+de+Gorgos.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Gata de Gorgos, &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 3"><span class="textsmall">Gata de Gorgos</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 3<br>
            <b>&euro; 290 000</b>	
</div>
</div>	
</div>

	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.co.uk/cache/img-tmc2/img_main18672.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~CY12956177.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1050;&#1080;&#1087;&#1088;, Paphos, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~CY12956177.htm" title="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1050;&#1080;&#1087;&#1088;, Paphos, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5"><b>&#1050;&#1080;&#1087;&#1088;</b></a> <br>
              &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;<br>
            Paphos<br>
              <a href="property_sales~scr~Cyprus~srg~Paphos~sltcity~Konia.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Konia, &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5"><span class="textsmall">Konia</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5<br>
            <b>&euro; 1 290 000</b>	
</div>
</div>	
</div>

	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.co.uk/cache/img-xml/1074_1_4.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~FR7937168.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1090;&#1072;&#1091;&#1085;-&#1093;&#1072;&#1091;&#1089;&#1099; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1060;&#1088;&#1072;&#1085;&#1094;&#1080;&#1103;, Poitou-Charentes, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 2"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~FR7937168.htm" title="&#1090;&#1072;&#1091;&#1085;-&#1093;&#1072;&#1091;&#1089;&#1099; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1060;&#1088;&#1072;&#1085;&#1094;&#1080;&#1103;, Poitou-Charentes, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 2"><b>&#1060;&#1088;&#1072;&#1085;&#1094;&#1080;&#1103;</b></a> <br>
              &#1090;&#1072;&#1091;&#1085;-&#1093;&#1072;&#1091;&#1089;&#1099;<br>
            Poitou-Charentes<br>
              <a href="property_sales~scr~France~srg~Poitou-Charentes~sltcity~Jarnac.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Jarnac, &#1090;&#1072;&#1091;&#1085;-&#1093;&#1072;&#1091;&#1089;&#1099;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 2"><span class="textsmall">Jarnac</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 2<br>
            POA	
</div>
</div>	
</div>

</div>
				<div>

			
	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.co.uk/cache/img-tmc2/img_main18169.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~BB12957445.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1041;&#1072;&#1088;&#1073;&#1072;&#1076;&#1086;&#1089;, St. James, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~BB12957445.htm" title="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1041;&#1072;&#1088;&#1073;&#1072;&#1076;&#1086;&#1089;, St. James, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5"><b>&#1041;&#1072;&#1088;&#1073;&#1072;&#1076;&#1086;&#1089;</b></a> <br>
              &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;<br>
            St. James<br>
              <a href="property_sales~scr~Barbados~srg~St.+James~sltcity~Westmoreland.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Westmoreland, &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5"><span class="textsmall">Westmoreland</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 5<br>
            <b>&euro; 2 826 396</b>	
</div>
</div>	
</div>

	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.co.uk/cache/img-xml/o5331780-residential-14pta34-o_4.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~US12969678.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1040;&#1084;&#1077;&#1088;&#1080;&#1082;&#1072;, Florida, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 2"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~US12969678.htm" title="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1040;&#1084;&#1077;&#1088;&#1080;&#1082;&#1072;, Florida, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 2"><b>&#1040;&#1084;&#1077;&#1088;&#1080;&#1082;&#1072;</b></a> <br>
              &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;<br>
            Florida<br>
              <a href="property_sales~scr~USA~srg~Florida~sltcity~Orlando+FL.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Orlando FL, &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 2"><span class="textsmall">Orlando FL</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 2<br>
            <b>$ 79 000</b>	
</div>
</div>	
</div>

	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.co.uk/cache/img-xml3/thumb_6074.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~TH7772131.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1058;&#1072;&#1080;&#1083;&#1072;&#1085;&#1076;, Phuket, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 4"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~TH7772131.htm" title="&#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1058;&#1072;&#1080;&#1083;&#1072;&#1085;&#1076;, Phuket, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 4"><b>&#1058;&#1072;&#1080;&#1083;&#1072;&#1085;&#1076;</b></a> <br>
              &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;<br>
            Phuket<br>
              <a href="property_sales~scr~Thailand~srg~Phuket~sltcity~Bang+Tao.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Bang Tao, &#1042;&#1080;&#1083;&#1083;&#1099;-&#1044;&#1086;&#1084;&#1072;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 4"><span class="textsmall">Bang Tao</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 4<br>
            <b>&euro; 1 017 648</b>	
</div>
</div>	
</div>

	
	<div class="flleft">
	<div align="center" style="margin-top:4px">
                                  <div style="background-image:url('http://www.holprop.co.uk/cache/img-xml/o5331916-residential-g32c8m-o_4.jpg'); background-repeat: no-repeat; width:132px; height:100px; background-position:center"><a href="http://www.holprop.ru/s/sale-property~id~US12969778.htm"><img src="http://www.holprop.ru/images/a-border.gif" width="132" height="100" border="0" alt="&#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1085;&#1099;&#1077; &#1076;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1040;&#1084;&#1077;&#1088;&#1080;&#1082;&#1072;, Florida, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 2"></a></div>
                        <div align="center" class="textsmall" style="padding-top:2px;">
						<a href="http://www.holprop.ru/s/sale-property~id~US12969778.htm" title="&#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1085;&#1099;&#1077; &#1076;&#1086;&#1084;&#1072; &#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; &#1040;&#1084;&#1077;&#1088;&#1080;&#1082;&#1072;, Florida, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 2"><b>&#1040;&#1084;&#1077;&#1088;&#1080;&#1082;&#1072;</b></a> <br>
              &#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1085;&#1099;&#1077; &#1076;&#1086;&#1084;&#1072;<br>
            Florida<br>
              <a href="property_sales~scr~USA~srg~Florida~sltcity~Altamonte+Springs+FL.htm" STYLE="text-decoration:none" title="&#1074; &#1055;&#1088;&#1086;&#1076;&#1072;&#1078;&#1072; Altamonte Springs FL, &#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1085;&#1099;&#1077; &#1076;&#1086;&#1084;&#1072;, &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 2"><span class="textsmall">Altamonte Springs FL</span></a><br>
              
              &#1057;&#1087;&#1072;&#1083;&#1100;&#1085;&#1080;: 2<br>
            <b>$ 77 500</b>	
</div>
</div>	
</div>

</div>
</div>
<!--End-->
					  
</div>

</div>

<div style="position:absolute; top:570px; padding-left:16px;"><H3 class="textsmall">&#1048;&#1097;&#1077;&#1090;&#1077; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100; &#1076;&#1083;&#1103; &#1087;&#1086;&#1082;&#1091;&#1087;&#1082;&#1080; &#1080;&#1083;&#1080; &#1083;&#1077;&#1090;&#1085;&#1080;&#1080;&#774; &#1076;&#1086;&#1084;&#1080;&#1082; &#1076;&#1083;&#1103; &#1072;&#1088;&#1077;&#1085;&#1076;&#1099;?</H3></div>
<div class="textsmall" style="padding-left:16px; padding-top:25px; padding-right:16px">
&#1042;&#1099; &#1086;&#1082;&#1072;&#1079;&#1072;&#1083;&#1080;&#1089;&#1100; &#1074; &#1085;&#1091;&#1078;&#1085;&#1086;&#1084; &#1084;&#1077;&#1089;&#1090;&#1077;! &#1053;&#1077;&#1079;&#1072;&#1074;&#1080;&#1089;&#1080;&#1084;&#1086; &#1086;&#1090; &#1090;&#1086;&#1075;&#1086;, &#1095;&#1090;&#1086; &#1074;&#1072;&#1084; &#1085;&#1091;&#1078;&#1085;&#1086; &mdash; &#1072;&#1088;&#1077;&#1085;&#1076;&#1086;&#1074;&#1072;&#1090;&#1100; &#1076;&#1086;&#1084; &#1076;&#1083;&#1103; &#1086;&#1090;&#1076;&#1099;&#1093;&#1072; &#1085;&#1072; &#1087;&#1083;&#1103;&#1078;&#1077;, &#1085;&#1072;&#1080;&#774;&#1090;&#1080; &#1084;&#1077;&#1073;&#1083;&#1080;&#1088;&#1086;&#1074;&#1072;&#1085;&#1085;&#1091;&#1102; &#1082;&#1074;&#1072;&#1088;&#1090;&#1080;&#1088;&#1091; &#1085;&#1072; &#1082;&#1086;&#1088;&#1086;&#1090;&#1082;&#1080;&#1080;&#774; &#1089;&#1088;&#1086;&#1082;, &#1082;&#1091;&#1087;&#1080;&#1090;&#1100; &#1076;&#1086;&#1084; &#1074;&#1072;&#1096;&#1077;&#1080;&#774; &#1084;&#1077;&#1095;&#1090;&#1099; &#1080;&#1083;&#1080; &#1087;&#1088;&#1086;&#1089;&#1090;&#1086; &#1089;&#1076;&#1077;&#1083;&#1072;&#1090;&#1100; &#1074;&#1099;&#1075;&#1086;&#1076;&#1085;&#1099;&#1077; &#1080;&#1085;&#1074;&#1077;&#1089;&#1090;&#1080;&#1094;&#1080;&#1080; &#1074; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100; &mdash; &#1074;&#1089;&#1077; &#1101;&#1090;&#1086; &#1074;&#1099; &#1084;&#1086;&#1078;&#1077;&#1090;&#1077; &#1085;&#1072;&#1080;&#774;&#1090;&#1080; &#1091; Holprop. 
Holprop.ru &#1089;&#1074;&#1103;&#1079;&#1099;&#1074;&#1072;&#1077;&#1090; &#1074;&#1072;&#1089; &#1085;&#1072;&#1087;&#1088;&#1103;&#1084;&#1091;&#1102; &#1089; &#1074;&#1083;&#1072;&#1076;&#1077;&#1083;&#1100;&#1094;&#1072;&#1084;&#1080; &#1080;&#1083;&#1080; &#1072;&#1075;&#1077;&#1085;&#1090;&#1072;&#1084;&#1080;, &#1087;&#1088;&#1077;&#1076;&#1083;&#1072;&#1075;&#1072;&#1102;&#1097;&#1080;&#1084;&#1080; &#1096;&#1080;&#1088;&#1086;&#1082;&#1080;&#1080;&#774; &#1074;&#1099;&#1073;&#1086;&#1088; &#1087;&#1088;&#1077;&#1076;&#1083;&#1086;&#1078;&#1077;&#1085;&#1080;&#1080;&#774; &#1082;&#1072;&#1082; &#1087;&#1086; <a href="property_sales.htm"><b>&#1087;&#1088;&#1086;&#1076;&#1072;&#1078;&#1077; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;</b></a>, &#1090;&#1072;&#1082; &#1080; &#1087;&#1086; <a href="holiday_rentals.htm"><b>&#1088;&#1077;&#1085;&#1076;&#1077; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;</b></a> &#1087;&#1086; &#1074;&#1089;&#1077;&#1084;&#1091; &#1084;&#1080;&#1088;&#1091;.
&#1055;&#1086;&#1089;&#1083;&#1077; &#1090;&#1086;&#1075;&#1086;, &#1082;&#1072;&#1082; &#1074;&#1099; &#1085;&#1072;&#1080;&#774;&#1076;&#1077;&#1090;&#1077; &#1087;&#1086;&#1085;&#1088;&#1072;&#1074;&#1080;&#1074;&#1096;&#1080;&#1080;&#774;&#1089;&#1103; &#1074;&#1072;&#1084; &#1076;&#1086;&#1084; &#1080;&#1083;&#1080; &#1076;&#1088;&#1091;&#1075;&#1086;&#1080;&#774; &#1086;&#1073;&#1098;&#1077;&#1082;&#1090; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;, &#1074;&#1099; &#1084;&#1086;&#1078;&#1077;&#1090;&#1077; &#1086;&#1073;&#1088;&#1072;&#1090;&#1080;&#1090;&#1100;&#1089;&#1103; &#1082; &#1074;&#1083;&#1072;&#1076;&#1077;&#1083;&#1100;&#1094;&#1091; &#1080;&#1083;&#1080; &#1072;&#1075;&#1077;&#1085;&#1090;&#1091; &#1085;&#1072;&#1087;&#1088;&#1103;&#1084;&#1091;&#1102;. &#1041;&#1077;&#1079; &#1087;&#1086;&#1089;&#1088;&#1077;&#1076;&#1085;&#1080;&#1082;&#1086;&#1074; &#1080; &#1076;&#1086;&#1087;&#1086;&#1083;&#1085;&#1080;&#1090;&#1077;&#1083;&#1100;&#1085;&#1099;&#1093; &#1082;&#1086;&#1084;&#1080;&#1089;&#1089;&#1080;&#1086;&#1085;&#1085;&#1099;&#1093; &#1089;&#1073;&#1086;&#1088;&#1086;&#1074;.
</div>
<!-- World Map -->
	<link href="maps-rentals/jqvmap.css" media="screen" rel="stylesheet" type="text/css">
    <script src="maps-rentals/jquery.vmap.js" type="text/javascript"></script>
    <script src="maps-rentals/jquery.vmap.world.js" type="text/javascript"></script>
<script src="maps-rentals/jquery.vmap.sampledata.js" type="text/javascript"></script>
    
	<script type="text/javascript">
	jQuery(document).ready(function() {
		jQuery('#vmap').vectorMap({
		    map: 'world_en',
		    backgroundColor: '#FFFFFF',
		    color: '#ffffff',
		    hoverOpacity: 0.7,
		    selectedColor: '#666666',
		    enableZoom: true,
		    showTooltip: true,
		    values: sample_data,
		    scaleColors: ['#C8EEFF', '#006491'],
		    normalizeFunction: 'polynomial',
			onRegionClick: function(element, code, region)
			
					{	
							window.location = "property_sales_ru.asp?scr="+region

					}
			});
		
	});
	</script>
        <div id="vmap" align="center" style="width: 720px; height: 500px;"></div>
        <!-- end of map -->
<div class="bgmain">
<div id="countrylist">
<div>		<A href="property_sales~scr~Cont3.htm"><b>&#1040;&#1074;&#1089;&#1090;&#1088;&#1072;&#1083;&#1080;&#1103;-&#1054;&#1082;&#1077;&#1072;&#1085;&#1080;&#1103;</b></A><br>
                                  
      &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Australia.htm">&#1040;&#1074;&#1089;&#1090;&#1088;&#1072;&#1083;&#1080;&#1103; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Fiji.htm">&#1060;&#1080;&#1076;&#1078;&#1080; &#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~New+Zealand.htm">&#1053;&#1086;&#1074;&#1072;&#1103; &#1047;&#1077;&#1083;&#1072;&#1085;&#1076;&#1080;&#1103; &#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A><br>
                                  <BR>
                                  
                                  <A href="property_sales~scr~Cont7.htm"><b>&#1041;&#1083;&#1080;&#1078;&#1085;&#1077;&#1074;&#1086;&#1089;&#1090;&#1086;&#1095;&#1085;&#1099;&#1081;</b></A><br>
       &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Egypt.htm">&#1045;&#1075;&#1080;&#1087;&#1077;&#1090; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~U.A.E..htm">&#1054;&#1040;&#1069; &#1044;&#1091;&#1073;&#1072;&#1081; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;</A><br>
                                  <BR>
                                  
                                 <A href="property_sales~scr~Cont11.htm"><b>&#1070;&#1075;&#1086;-&#1042;&#1086;&#1089;&#1090;&#1086;&#1095;&#1085;&#1086;&#1081; &#1040;&#1079;&#1080;&#1080;</b></A><br>
                                 
      &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Malaysia.htm">&#1052;&#1072;&#1083;&#1072;&#1081;&#1079;&#1080;&#1103; &#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Philippines.htm">&#1060;&#1080;&#1083;&#1080;&#1087;&#1087;&#1080;&#1085;&#1099; &#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Thailand.htm">&#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100; &#1058;&#1072;&#1080;&#1083;&#1072;&#1085;&#1076;&#1072;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Indonesia.htm">&#1048;&#1085;&#1076;&#1086;&#1085;&#1077;&#1079;&#1080;&#1103; &#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A><br>
                                  <BR>
                                  
                                 <A href="property_sales~scr~Cont1.htm"><b>&#1040;&#1092;&#1088;&#1080;&#1082;&#1072;&#1085;&#1089;&#1082;&#1080;&#1081; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;</b></A><br>
                                  
       &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Cape+Verde.htm">&#1050;&#1072;&#1073;&#1086;-&#1042;&#1077;&#1088;&#1076;&#1077; &#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Mauritius.htm">&#1052;&#1072;&#1074;&#1088;&#1080;&#1082;&#1080;&#1081; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Morocco.htm">&#1052;&#1072;&#1088;&#1086;&#1082;&#1082;&#1086; &#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~South+Africa.htm">&#1070;&#1078;&#1085;&#1072;&#1103; &#1040;&#1092;&#1088;&#1080;&#1082;&#1072; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;</A><br>
								  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Tunisia.htm">&#1058;&#1091;&#1085;&#1080;&#1089; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;</A><br>
                                  <BR>
                                  
                                  <A href="property_sales~scr~Cont2.htm"><b>&#1072;&#1079;&#1080;&#1072;&#1090;&#1089;&#1082;&#1080;&#1077; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;</b></A><br>
                                  
      &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~India.htm">&#1048;&#1085;&#1076;&#1080;&#1103; &#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A><br>
                                &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~China+RP.htm">&#1056;&#1077;&#1089;&#1087;&#1091;&#1073;&#1083;&#1080;&#1082;&#1072; &#1050;&#1080;&#1090;&#1072;&#1081;</A>					  
	</div><div>
	
								<A href="property_sales~scr~Cont8.htm"><b>&#1057;&#1077;&#1074;&#1077;&#1088;&#1086;&#1072;&#1084;&#1077;&#1088;&#1080;&#1082;&#1072;&#1085;&#1089;&#1082;&#1080;&#1081;</b></A><br>
                                  
     &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Canada.htm">&#1050;&#1072;&#1085;&#1072;&#1076;&#1072; &#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Mexico.htm">&#1052;&#1077;&#1082;&#1089;&#1080;&#1082;&#1072; &#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~USA.htm">&#1040;&#1084;&#1077;&#1088;&#1080;&#1082;&#1072;&#1085;&#1089;&#1082;&#1072;&#1103; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A><br>
                                  <br>
                                  
                                 <A href="property_sales~scr~Cont5.htm"><b>&#1050;&#1072;&#1088;&#1080;&#1073;&#1089;&#1082;&#1080;&#1081; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;</b></A><br>
                                
      &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Bahamas.htm">&#1041;&#1072;&#1075;&#1072;&#1084;&#1089;&#1082;&#1080;&#1077; &#1086;&#1089;&#1090;&#1088;&#1086;&#1074;&#1072; &#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Barbados.htm">&#1041;&#1072;&#1088;&#1073;&#1072;&#1076;&#1086;&#1089; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Cayman+Island.htm">&#1050;&#1072;&#1081;&#1084;&#1072;&#1085;&#1086;&#1074;&#1099; &#1086;&#1089;&#1090;&#1088;&#1086;&#1074;&#1072; &#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Dominican+Republic.htm">&#1044;&#1086;&#1084;&#1080;&#1085;&#1080;&#1082;&#1072;&#1085;&#1089;&#1082;&#1072;&#1103; &#1056;&#1077;&#1089;&#1087;&#1091;&#1073;&#1083;&#1080;&#1082;&#1072;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Jamaica.htm">&#1071;&#1084;&#1072;&#1081;&#1082;&#1072; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~St.+Kitts-Nevis.htm">&#1057;&#1077;&#1085;&#1090;-&#1050;&#1080;&#1090;&#1089;&#1072; &#1080; &#1053;&#1077;&#1074;&#1080;&#1089;&#1072;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~St.+Lucia.htm">&#1057;&#1077;&#1085;&#1090;-&#1051;&#1102;&#1089;&#1080;&#1103; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~St.+Maarten.htm">&#1057;&#1077;&#1085;-&#1052;&#1072;&#1088;&#1090;&#1077;&#1085; &#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~St.+Vincent-Grenadines.htm">&#1057;&#1077;&#1085;&#1090;-&#1042;&#1080;&#1085;&#1089;&#1077;&#1085;&#1090;-&#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A><br>
                                  <br>
                                
                                <A href="property_sales~scr~Cont4.htm"><b>&#1062;&#1077;&#1085;&#1090;&#1088;&#1072;&#1083;&#1100;&#1085;&#1086;&#1081; &#1040;&#1084;&#1077;&#1088;&#1080;&#1082;&#1080;</b></A><br>
                             &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Belize.htm">&#1041;&#1077;&#1083;&#1080;&#1079; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;</A><br>
                                &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Costa+Rica.htm">&#1050;&#1086;&#1089;&#1090;&#1072;-&#1056;&#1080;&#1082;&#1072; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;</A><br>
                                &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Panama.htm">&#1055;&#1072;&#1085;&#1072;&#1084;&#1072; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;</A><br>
							&nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Nicaragua.htm">&#1053;&#1080;&#1082;&#1072;&#1088;&#1072;&#1075;&#1091;&#1072; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;</a><br>
                            
                                <br>
                                
                                <A href="property_sales~scr~Cont10.htm"><b>&#1070;&#1078;&#1085;&#1086;&#1072;&#1084;&#1077;&#1088;&#1080;&#1082;&#1072;&#1085;&#1089;&#1082;&#1080;&#1081; &#1089;&#1074;&#1086;&#1081;&#1089;&#1090;&#1074;&#1072;</b></A><br>
                             
      &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Argentina.htm">&#1040;&#1088;&#1075;&#1077;&#1085;&#1090;&#1080;&#1085;&#1072; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;</A><br>
                                &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Brazil.htm">&#1041;&#1088;&#1072;&#1079;&#1080;&#1083;&#1080;&#1103; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;</A>
	</div><div>
								<A href="property_sales~scr~Cont6.htm"><b>&#1077;&#1074;&#1088;&#1086;&#1087;&#1077;&#1081;&#1089;&#1082;&#1086;&#1081; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;</b></A><br>
							&nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Albania.htm">&#1040;&#1083;&#1073;&#1072;&#1085;&#1080;&#1103; &#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Austria.htm">&#1040;&#1074;&#1089;&#1090;&#1088;&#1080;&#1103; &#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Bulgaria.htm">&#1041;&#1086;&#1083;&#1075;&#1072;&#1088;&#1080;&#1103; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Croatia.htm">&#1061;&#1086;&#1088;&#1074;&#1072;&#1090;&#1080;&#1103; &#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Cyprus.htm">&#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100; &#1085;&#1072; &#1050;&#1080;&#1087;&#1088;&#1077;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~England.htm">&#1040;&#1085;&#1075;&#1083;&#1080;&#1103; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~France.htm">&#1060;&#1088;&#1072;&#1085;&#1094;&#1080;&#1103; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Germany.htm">&#1043;&#1077;&#1088;&#1084;&#1072;&#1085;&#1080;&#1103; &#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A><br>
								  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Greece.htm">&#1043;&#1088;&#1077;&#1094;&#1080;&#1103; &#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Gibraltar.htm">&#1043;&#1080;&#1073;&#1088;&#1072;&#1083;&#1090;&#1072;&#1088; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Hungary.htm">&#1042;&#1077;&#1085;&#1075;&#1088;&#1080;&#1103; &#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Italy.htm">&#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100; &#1048;&#1090;&#1072;&#1083;&#1080;&#1080;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Malta.htm">&#1052;&#1072;&#1083;&#1100;&#1090;&#1072; &#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Monaco.htm">&#1052;&#1086;&#1085;&#1072;&#1094;&#1086; &#1056;&#1077;&#1072;&#1083; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Montenegro.htm">&#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100; &#1063;&#1077;&#1088;&#1085;&#1086;&#1075;&#1086;&#1088;&#1080;&#1080;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Poland.htm">&#1055;&#1086;&#1083;&#1100;&#1096;&#1072; &#1063;&#1077;&#1088;&#1085;&#1086;&#1075;&#1086;&#1088;&#1080;&#1080;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Portugal.htm">&#1055;&#1086;&#1088;&#1090;&#1091;&#1075;&#1072;&#1083;&#1080;&#1103; &#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Romania.htm">&#1056;&#1091;&#1084;&#1099;&#1085;&#1080;&#1103; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Slovakia.htm">&#1057;&#1083;&#1086;&#1074;&#1072;&#1082;&#1080;&#1103; &#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Slovenia.htm">&#1057;&#1083;&#1086;&#1074;&#1077;&#1085;&#1080;&#1103; &#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Spain.htm">&#1048;&#1089;&#1087;&#1072;&#1085;&#1080;&#1103; &#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Sweden.htm">&#1064;&#1074;&#1077;&#1094;&#1080;&#1103; &#1085;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1080;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Switzerland.htm">&#1064;&#1074;&#1077;&#1081;&#1094;&#1072;&#1088;&#1080;&#1103; &#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A><br>
                                  &nbsp;&nbsp;&nbsp;<A href="property_sales~scr~Turkey.htm">&#1058;&#1091;&#1088;&#1094;&#1080;&#1103; &#1053;&#1077;&#1076;&#1074;&#1080;&#1078;&#1080;&#1084;&#1086;&#1089;&#1090;&#1100;</A>
	</div>
</div>
</div>
</div>
<div id="bottomlinks">
<ul>
				<li><a href="https://www.facebook.com/holprop" target="_blank">Holprop on Facebook</a></li>
				<li><a href="http://twitter.com/#!/holpropt" target="_blank">Follow us on Twitter</a></li>
				<li style="text-align:center"><a href="http://www.holprop.com/rentacar/cheap-carhire.asp" target="_blank">&#1040;&#1088;&#1077;&#1085;&#1076;&#1072; &#1072;&#1074;&#1090;&#1086;&#1084;&#1086;&#1073;&#1080;&#1083;&#1077;&#1080;&#774;</a>
				<div style="position:absolute; top:705px; width:140px;" class="text-gray-reject" align="left">&#1091;&#1074;&#1077;&#1083;&#1080;&#1095;&#1080;&#1090;&#1100; &#1082;&#1072;&#1088;&#1090;&#1091;</div>
				</li>
				<li style="text-align:center"><a href="http://www.holprop.com/flights/cheap-flights.asp" target="_blank">&#1072;&#1074;&#1080;&#1072;&#1073;&#1080;&#1083;&#1077;&#1090;&#1099;</a></li>
				<li style="text-align:center"><a href="http://www.holprop.com/insurance/home-insurance.asp">&#1057;&#1090;&#1088;&#1072;&#1093;&#1086;&#1074;&#1072;&#1085;&#1080;&#1077;</a></li>
				<li style="text-align:center"><a href="http://www.mortgagecalculator4free.com/" target="_blank">&#1082;&#1072;&#1083;&#1100;&#1082;&#1091;&#1083;&#1103;&#1090;&#1086;&#1088; &#1079;&#1072;&#1082;&#1083;&#1072;&#1076;&#1072;</a>
				<div style="position:absolute; top:95px; width:250px;" class="textsmall" align="right">
<div id="fb-root" align="right"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/ru_RU/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><div class="fb-like" data-href="https://www.facebook.com/holprop" data-width="450" data-layout="button_count" data-show-faces="false" data-send="true"></div>
</div>
</li>
				<li style="text-align:center"><a href="http://www.holprop.com/investments/">&#1080;&#1085;&#1074;&#1077;&#1089;&#1090;&#1080;&#1094;&#1080;&#1080;</a></li>
	  </ul>
</div>

<div style="background-image:url(images/front-bt2.jpg); height:40px">
</div>
</div>


  
  <div id="footer">
<div class="text-small-white" style="padding-top:10px" align="center">
Copyright &copy; Holprop LTD. &#1042;&#1089;&#1077; &#1087;&#1088;&#1072;&#1074;&#1072; &#1079;&#1072;&#1097;&#1080;&#1097;&#1077;&#1085;&#1099; | <a href="http://www.m.holprop.com/ru/" style="text-decoration:none"><span class="text-small-white">Holprop Mobile</span></a> | <a href="http://www.holprop.com/contact_us.asp" style="text-decoration:none"><span class="text-small-white">&#1050;&#1086;&#1085;&#1090;&#1072;&#1082;&#1090;&#1085;&#1072;&#1103;</span></a> | <a href="http://www.holprop.com/privacy_statement.asp" target="_blank" style="text-decoration:none"><span class="text-small-white">Privacy-Cookies</span></a></div>

</div>
</div>

<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-711085-7";
urchinTracker();
</script>

</body>
</html>
