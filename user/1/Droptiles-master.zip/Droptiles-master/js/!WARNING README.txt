﻿Whenever you make changes to any of the Javascripts, 
make sure you run the Combined.bat file and generate
the Combined.js file. The pages load the Combined.js file,
not the individual JS file. 

Also make sure you update the version ref to the Combined.js
file on the pages. 